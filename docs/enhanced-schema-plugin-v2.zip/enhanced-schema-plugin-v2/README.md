# Enhanced Schema Plugin

**Version:** 1.0.0  
**Author:** Your Agency  
**License:** GPL-2.0+

## Description

Comprehensive schema markup plugin with automated webpage schema, local business georadius, entity detection, and 12+ schema types. Perfect for agencies managing multiple client websites.

## Features

### Core Features
- **Automated Webpage Schema** - Automatically generates schema for all pages and posts
- **Organization Schema** - Complete company information and branding
- **Local Business Schema** - Full local business markup with georadius support
- **Georadius & Service Area** - Define service areas using postal codes and radius
- **12+ Schema Types** - Webpage, Organization, LocalBusiness, Article, Breadcrumb, Video, FAQ, Product, Event, Recipe, Person, Review
- **Entity Detection** - Automatic entity detection from content (Wikipedia/Wikidata integration ready)
- **Schema Validation** - Built-in validator and Google Rich Results Test integration
- **Theme Independent** - Works with any WordPress theme
- **SEO Plugin Independent** - Compatible with Rank Math, Yoast, and other SEO plugins

### Admin Features
- **Intuitive Dashboard** - Clear overview of schema status and active types
- **Easy Configuration** - Simple settings for enabling/disabling schema types
- **Organization Manager** - Complete form for organization details, contact info, and social media
- **Business Manager** - Local business configuration with hours, pricing, and service area
- **Schema Generator** - Test and preview schema before going live
- **Copy to Clipboard** - Easy copying of generated schema for testing

## Installation

### Automatic Installation
1. Log in to your WordPress admin panel
2. Navigate to **Plugins → Add Plugin**
3. Click **Upload Plugin** button
4. Choose the `enhanced-schema-plugin.zip` file
5. Click **Install Now**
6. Activate the plugin

### Manual Installation
1. Upload the `enhanced-schema-plugin` folder to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** menu in WordPress
3. Navigate to **Enhanced Schema** in the admin menu

## Quick Start Guide

### 1. Configure Settings
- Go to **Enhanced Schema → Settings**
- Enable schema generation
- Select which schema types to activate
- Enable entity detection and caching if desired

### 2. Add Organization Information
- Go to **Enhanced Schema → Organization**
- Fill in your company name, logo, and description
- Add contact information (email, phone)
- Enter your business address
- Add social media profiles

### 3. Set Up Local Business (if applicable)
- Go to **Enhanced Schema → Local Business**
- Select your business type (HVAC, Plumber, Restaurant, etc.)
- Enter location coordinates (latitude/longitude)
- Define service radius in miles
- Add postal codes you serve (comma-separated)
- Set business hours for each day

### 4. Test Your Schema
- Go to **Enhanced Schema → Schema Generator**
- Select a schema type to generate
- Click **Generate Schema**
- Copy the output and test in [Google Rich Results Test](https://search.google.com/test/rich-results)

### 5. Verify on Your Site
- Visit any page on your site
- View page source (right-click → View Page Source)
- Search for `application/ld+json` to see the schema markup
- Verify it appears correctly in the `<head>` section

## Schema Types

### Webpage Schema
Automatically generated for all pages and posts. Includes title, description, author, publisher, and featured image.

### Organization Schema
Company information including name, logo, contact details, address, and social media profiles.

### Local Business Schema
Complete local business markup with:
- Business type (HVAC, Plumber, Restaurant, etc.)
- Location and geo coordinates
- Service area (georadius with postal codes)
- Business hours
- Price range
- Contact information

### Article Schema
Enhanced article markup for blog posts with author, publisher, dates, and images.

### Breadcrumb Schema
Automatic breadcrumb navigation schema for better site structure in search results.

### Additional Schema Types
- **Video Schema** - For embedded videos
- **FAQ Schema** - For FAQ content
- **Product Schema** - For e-commerce products
- **Event Schema** - For events and calendars
- **Recipe Schema** - For food and cooking sites
- **Person Schema** - For author profiles
- **Review Schema** - For ratings and reviews

## Georadius & Service Area

The plugin supports advanced service area definition:

### By Radius
Define a circular service area using:
- Center point (latitude/longitude)
- Radius in miles

### By Postal Codes
List specific postal codes you serve:
```
10001, 10002, 10003, 10004
```

### Combined Approach
Use both radius and postal codes for maximum coverage and precision.

## Compatibility

- **WordPress:** 5.0 or higher
- **PHP:** 7.4 or higher
- **Themes:** All WordPress themes
- **SEO Plugins:** Compatible with Rank Math, Yoast SEO, All in One SEO, and others
- **Page Builders:** Elementor, Divi, Beaver Builder, Gutenberg, and others

## Frequently Asked Questions

### Does this work with my SEO plugin?
Yes! The Enhanced Schema Plugin is designed to work alongside popular SEO plugins like Rank Math, Yoast SEO, and All in One SEO. It adds additional schema types they don't cover.

### Will this slow down my site?
No. The plugin is optimized for performance with entity caching and efficient schema generation. Schema is output directly in the HTML with no external requests.

### Do I need API keys?
No API keys are required for basic functionality. The plugin works out of the box. Advanced features like entity detection from Wikipedia/Wikidata can be enabled optionally.

### Can I use this on multiple sites?
Yes! This plugin is perfect for agencies managing multiple client websites. Install it on as many sites as you need.

### How do I test my schema?
Use the built-in Schema Generator (Enhanced Schema → Schema Generator) to preview schema, then test it in Google's Rich Results Test tool.

### What if I only need Organization schema?
Simply enable only the schema types you need in Settings. Disable the others to keep your markup clean.

## Support

For support, feature requests, or bug reports, please contact your agency representative or visit our support portal.

## Changelog

### 1.0.0 - 2024-11-24
- Initial release
- Automated webpage schema generation
- Organization schema with full company details
- Local business schema with georadius support
- 12+ schema types
- Schema generator and validator
- Intuitive admin interface
- Theme and SEO plugin independent

## Credits

Developed by Your Agency for professional WordPress websites.

## License

This plugin is licensed under the GPL-2.0+ license.
