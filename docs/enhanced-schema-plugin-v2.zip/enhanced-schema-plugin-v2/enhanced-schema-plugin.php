<?php
/**
 * Plugin Name: Enhanced Schema Plugin
 * Plugin URI: https://youragency.com/enhanced-schema
 * Description: Comprehensive schema markup plugin with automated webpage schema, local business georadius, entity detection, and 12+ schema types. Perfect for agencies managing multiple client websites.
 * Version: 1.0.0
 * Author: Your Agency
 * Author URI: https://youragency.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: enhanced-schema
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Plugin version
define('ENHANCED_SCHEMA_VERSION', '1.0.0');

// Plugin paths
define('ENHANCED_SCHEMA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ENHANCED_SCHEMA_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * The code that runs during plugin activation
 */
function activate_enhanced_schema() {
    // Set default options
    $default_settings = array(
        'enabled' => true,
        'schema_types' => array(
            'webpage' => true,
            'organization' => true,
            'localbusiness' => false,
            'video' => true,
            'faq' => true,
            'article' => true,
            'product' => false,
            'event' => false,
            'recipe' => false,
            'breadcrumb' => true,
            'person' => false,
            'review' => false
        ),
        'auto_detect_entities' => true,
        'cache_entities' => true
    );
    
    if (!get_option('enhanced_schema_settings')) {
        add_option('enhanced_schema_settings', $default_settings);
    }
    
    // Create cached entities option
    if (!get_option('enhanced_schema_cached_entities')) {
        add_option('enhanced_schema_cached_entities', array());
    }
}
register_activation_hook(__FILE__, 'activate_enhanced_schema');

/**
 * The code that runs during plugin deactivation
 */
function deactivate_enhanced_schema() {
    // Clear cached entities
    delete_transient('enhanced_schema_entities');
}
register_deactivation_hook(__FILE__, 'deactivate_enhanced_schema');

/**
 * Load plugin classes
 */
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-schema-generator.php';
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-admin.php';
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-frontend.php';

/**
 * Initialize the plugin
 */
function run_enhanced_schema() {
    // Initialize admin
    if (is_admin()) {
        $admin = new Enhanced_Schema_Admin();
        $admin->init();
    }
    
    // Initialize frontend
    $frontend = new Enhanced_Schema_Frontend();
    $frontend->init();
}
add_action('plugins_loaded', 'run_enhanced_schema');
