<?php
/**
 * Admin functionality
 */
class Enhanced_Schema_Admin {
    
    public function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_enhanced_schema_generate', array($this, 'ajax_generate_schema'));
        add_action('wp_ajax_enhanced_schema_validate', array($this, 'ajax_validate_schema'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Enhanced Schema',
            'Enhanced Schema',
            'manage_options',
            'enhanced-schema',
            array($this, 'render_dashboard'),
            'dashicons-networking',
            30
        );
        
        add_submenu_page(
            'enhanced-schema',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'enhanced-schema',
            array($this, 'render_dashboard')
        );
        
        add_submenu_page(
            'enhanced-schema',
            'Settings',
            'Settings',
            'manage_options',
            'enhanced-schema-settings',
            array($this, 'render_settings')
        );
        
        add_submenu_page(
            'enhanced-schema',
            'Organization',
            'Organization',
            'manage_options',
            'enhanced-schema-organization',
            array($this, 'render_organization')
        );
        
        add_submenu_page(
            'enhanced-schema',
            'Local Business',
            'Local Business',
            'manage_options',
            'enhanced-schema-business',
            array($this, 'render_business')
        );
        
        add_submenu_page(
            'enhanced-schema',
            'Schema Generator',
            'Schema Generator',
            'manage_options',
            'enhanced-schema-generator',
            array($this, 'render_generator')
        );
    }
    
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'enhanced-schema') === false) {
            return;
        }
        
        wp_enqueue_style(
            'enhanced-schema-admin',
            ENHANCED_SCHEMA_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            ENHANCED_SCHEMA_VERSION
        );
        
        wp_enqueue_script(
            'enhanced-schema-admin',
            ENHANCED_SCHEMA_PLUGIN_URL . 'admin/js/admin.js',
            array('jquery'),
            ENHANCED_SCHEMA_VERSION,
            true
        );
        
        wp_localize_script('enhanced-schema-admin', 'enhancedSchemaAjax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('enhanced_schema_nonce')
        ));
    }
    
    public function register_settings() {
        register_setting('enhanced_schema_settings', 'enhanced_schema_settings');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization');
        register_setting('enhanced_schema_business', 'enhanced_schema_business');
    }
    
    public function render_dashboard() {
        $settings = get_option('enhanced_schema_settings', array());
        $enabled = isset($settings['enabled']) ? $settings['enabled'] : true;
        $schema_types = isset($settings['schema_types']) ? $settings['schema_types'] : array();
        $enabled_count = count(array_filter($schema_types));
        $cached_entities = get_option('enhanced_schema_cached_entities', array());
        
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/dashboard.php';
    }
    
    public function render_settings() {
        if (isset($_POST['enhanced_schema_settings_submit'])) {
            check_admin_referer('enhanced_schema_settings');
            
            $settings = array(
                'enabled' => isset($_POST['enabled']) ? true : false,
                'schema_types' => isset($_POST['schema_types']) ? $_POST['schema_types'] : array(),
                'auto_detect_entities' => isset($_POST['auto_detect_entities']) ? true : false,
                'cache_entities' => isset($_POST['cache_entities']) ? true : false
            );
            
            update_option('enhanced_schema_settings', $settings);
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }
        
        $settings = get_option('enhanced_schema_settings', array());
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/settings.php';
    }
    
    public function render_organization() {
        if (isset($_POST['enhanced_schema_organization_submit'])) {
            check_admin_referer('enhanced_schema_organization');
            
            $organization = array(
                'name' => sanitize_text_field($_POST['org_name']),
                'legal_name' => sanitize_text_field($_POST['org_legal_name']),
                'url' => esc_url_raw($_POST['org_url']),
                'logo' => esc_url_raw($_POST['org_logo']),
                'description' => sanitize_textarea_field($_POST['org_description']),
                'email' => sanitize_email($_POST['org_email']),
                'phone' => sanitize_text_field($_POST['org_phone']),
                'address' => array(
                    'street' => sanitize_text_field($_POST['org_street']),
                    'city' => sanitize_text_field($_POST['org_city']),
                    'state' => sanitize_text_field($_POST['org_state']),
                    'postal_code' => sanitize_text_field($_POST['org_postal_code']),
                    'country' => sanitize_text_field($_POST['org_country'])
                ),
                'social' => array(
                    'facebook' => esc_url_raw($_POST['org_facebook']),
                    'twitter' => esc_url_raw($_POST['org_twitter']),
                    'linkedin' => esc_url_raw($_POST['org_linkedin']),
                    'instagram' => esc_url_raw($_POST['org_instagram'])
                )
            );
            
            update_option('enhanced_schema_organization', $organization);
            echo '<div class="notice notice-success"><p>Organization information saved successfully!</p></div>';
        }
        
        $organization = get_option('enhanced_schema_organization', array());
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/organization.php';
    }
    
    public function render_business() {
        if (isset($_POST['enhanced_schema_business_submit'])) {
            check_admin_referer('enhanced_schema_business');
            
            $business = array(
                'type' => sanitize_text_field($_POST['business_type']),
                'name' => sanitize_text_field($_POST['business_name']),
                'price_range' => sanitize_text_field($_POST['business_price_range']),
                'hours' => isset($_POST['business_hours']) ? $_POST['business_hours'] : array(),
                'geo' => array(
                    'latitude' => floatval($_POST['business_latitude']),
                    'longitude' => floatval($_POST['business_longitude']),
                    'radius' => intval($_POST['business_radius']),
                    'postal_codes' => sanitize_textarea_field($_POST['business_postal_codes'])
                ),
                'service_area' => sanitize_textarea_field($_POST['business_service_area'])
            );
            
            update_option('enhanced_schema_business', $business);
            echo '<div class="notice notice-success"><p>Business information saved successfully!</p></div>';
        }
        
        $business = get_option('enhanced_schema_business', array());
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/business.php';
    }
    
    public function render_generator() {
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/generator.php';
    }
    
    public function ajax_generate_schema() {
        check_ajax_referer('enhanced_schema_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $schema_type = isset($_POST['schema_type']) ? sanitize_text_field($_POST['schema_type']) : 'webpage';
        
        $generator = new Enhanced_Schema_Generator();
        $schema = $generator->generate_schema($schema_type, $post_id);
        
        wp_send_json_success(array(
            'schema' => $schema,
            'json' => json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
        ));
    }
    
    public function ajax_validate_schema() {
        check_ajax_referer('enhanced_schema_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $schema_json = isset($_POST['schema']) ? stripslashes($_POST['schema']) : '';
        
        // Validate JSON
        $schema = json_decode($schema_json);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(array('message' => 'Invalid JSON: ' . json_last_error_msg()));
        }
        
        // Basic schema.org validation
        if (!isset($schema->{'@context'}) || !isset($schema->{'@type'})) {
            wp_send_json_error(array('message' => 'Schema must include @context and @type'));
        }
        
        wp_send_json_success(array('message' => 'Schema is valid!'));
    }
}
