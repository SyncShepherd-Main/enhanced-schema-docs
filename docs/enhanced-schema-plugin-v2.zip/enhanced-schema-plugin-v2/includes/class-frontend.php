<?php
/**
 * Frontend functionality - outputs schema to pages
 */
class Enhanced_Schema_Frontend {
    
    public function init() {
        add_action('wp_head', array($this, 'output_schema'), 1);
    }
    
    public function output_schema() {
        $settings = get_option('enhanced_schema_settings', array());
        
        // Check if schema is enabled
        if (empty($settings['enabled'])) {
            return;
        }
        
        $schema_types = isset($settings['schema_types']) ? $settings['schema_types'] : array();
        $generator = new Enhanced_Schema_Generator();
        $schemas = array();
        
        // Organization schema (sitewide)
        if (!empty($schema_types['organization'])) {
            $org_schema = $generator->generate_organization_schema();
            if (!empty($org_schema)) {
                $schemas[] = $org_schema;
            }
        }
        
        // Local Business schema (sitewide)
        if (!empty($schema_types['localbusiness'])) {
            $business_schema = $generator->generate_localbusiness_schema();
            if (!empty($business_schema)) {
                $schemas[] = $business_schema;
            }
        }
        
        // Page-specific schemas
        if (is_singular()) {
            // Webpage/Article schema
            if (!empty($schema_types['webpage'])) {
                $webpage_schema = $generator->generate_webpage_schema();
                if (!empty($webpage_schema)) {
                    $schemas[] = $webpage_schema;
                }
            }
            
            // Article schema for posts
            if (is_single() && !empty($schema_types['article'])) {
                $article_schema = $generator->generate_article_schema();
                if (!empty($article_schema)) {
                    $schemas[] = $article_schema;
                }
            }
            
            // Breadcrumb schema
            if (!empty($schema_types['breadcrumb'])) {
                $breadcrumb_schema = $generator->generate_breadcrumb_schema();
                if (!empty($breadcrumb_schema)) {
                    $schemas[] = $breadcrumb_schema;
                }
            }
        }
        
        // Output schemas
        if (!empty($schemas)) {
            echo "\n<!-- Enhanced Schema Plugin -->\n";
            foreach ($schemas as $schema) {
                echo '<script type="application/ld+json">' . "\n";
                echo json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                echo "\n" . '</script>' . "\n";
            }
            echo "<!-- /Enhanced Schema Plugin -->\n\n";
        }
    }
}
