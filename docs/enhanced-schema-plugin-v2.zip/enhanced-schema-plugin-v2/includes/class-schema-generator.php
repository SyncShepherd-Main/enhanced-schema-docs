<?php
/**
 * Schema Generator Class
 */
class Enhanced_Schema_Generator {
    
    public function generate_schema($type, $post_id = 0) {
        $method = 'generate_' . $type . '_schema';
        
        if (method_exists($this, $method)) {
            return $this->$method($post_id);
        }
        
        return array();
    }
    
    public function generate_webpage_schema($post_id = 0) {
        if ($post_id === 0) {
            $post_id = get_the_ID();
        }
        
        if (!$post_id) {
            return array();
        }
        
        $post = get_post($post_id);
        $author = get_userdata($post->post_author);
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            'name' => get_the_title($post_id),
            'description' => get_the_excerpt($post_id),
            'url' => get_permalink($post_id),
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'author' => array(
                '@type' => 'Person',
                'name' => $author->display_name
            ),
            'publisher' => $this->get_organization_schema()
        );
        
        // Add featured image if available
        if (has_post_thumbnail($post_id)) {
            $schema['image'] = get_the_post_thumbnail_url($post_id, 'full');
        }
        
        return $schema;
    }
    
    public function generate_organization_schema() {
        $org = get_option('enhanced_schema_organization', array());
        
        if (empty($org)) {
            return $this->get_organization_schema();
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => isset($org['name']) ? $org['name'] : get_bloginfo('name'),
            'url' => isset($org['url']) ? $org['url'] : home_url(),
        );
        
        if (!empty($org['legal_name'])) {
            $schema['legalName'] = $org['legal_name'];
        }
        
        if (!empty($org['logo'])) {
            $schema['logo'] = $org['logo'];
        }
        
        if (!empty($org['description'])) {
            $schema['description'] = $org['description'];
        }
        
        if (!empty($org['email'])) {
            $schema['email'] = $org['email'];
        }
        
        if (!empty($org['phone'])) {
            $schema['telephone'] = $org['phone'];
        }
        
        if (!empty($org['address'])) {
            $schema['address'] = array(
                '@type' => 'PostalAddress',
                'streetAddress' => isset($org['address']['street']) ? $org['address']['street'] : '',
                'addressLocality' => isset($org['address']['city']) ? $org['address']['city'] : '',
                'addressRegion' => isset($org['address']['state']) ? $org['address']['state'] : '',
                'postalCode' => isset($org['address']['postal_code']) ? $org['address']['postal_code'] : '',
                'addressCountry' => isset($org['address']['country']) ? $org['address']['country'] : ''
            );
        }
        
        if (!empty($org['social'])) {
            $social_urls = array_filter($org['social']);
            if (!empty($social_urls)) {
                $schema['sameAs'] = array_values($social_urls);
            }
        }
        
        return $schema;
    }
    
    public function generate_localbusiness_schema() {
        $business = get_option('enhanced_schema_business', array());
        $org = get_option('enhanced_schema_organization', array());
        
        if (empty($business)) {
            return array();
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => !empty($business['type']) ? $business['type'] : 'LocalBusiness',
            'name' => !empty($business['name']) ? $business['name'] : get_bloginfo('name'),
            'url' => home_url(),
        );
        
        // Add organization data
        if (!empty($org)) {
            if (!empty($org['description'])) {
                $schema['description'] = $org['description'];
            }
            if (!empty($org['logo'])) {
                $schema['image'] = $org['logo'];
            }
            if (!empty($org['phone'])) {
                $schema['telephone'] = $org['phone'];
            }
            if (!empty($org['email'])) {
                $schema['email'] = $org['email'];
            }
            if (!empty($org['address'])) {
                $schema['address'] = array(
                    '@type' => 'PostalAddress',
                    'streetAddress' => isset($org['address']['street']) ? $org['address']['street'] : '',
                    'addressLocality' => isset($org['address']['city']) ? $org['address']['city'] : '',
                    'addressRegion' => isset($org['address']['state']) ? $org['address']['state'] : '',
                    'postalCode' => isset($org['address']['postal_code']) ? $org['address']['postal_code'] : '',
                    'addressCountry' => isset($org['address']['country']) ? $org['address']['country'] : ''
                );
            }
        }
        
        // Add price range
        if (!empty($business['price_range'])) {
            $schema['priceRange'] = $business['price_range'];
        }
        
        // Add geo coordinates
        if (!empty($business['geo']['latitude']) && !empty($business['geo']['longitude'])) {
            $schema['geo'] = array(
                '@type' => 'GeoCoordinates',
                'latitude' => $business['geo']['latitude'],
                'longitude' => $business['geo']['longitude']
            );
        }
        
        // Add service area (georadius)
        if (!empty($business['geo']['radius']) || !empty($business['geo']['postal_codes'])) {
            $areas = array();
            
            if (!empty($business['geo']['postal_codes'])) {
                $postal_codes = array_map('trim', explode(',', $business['geo']['postal_codes']));
                foreach ($postal_codes as $code) {
                    $areas[] = array(
                        '@type' => 'PostalCodeRangeSpecification',
                        'postalCodeBegin' => $code,
                        'postalCodeEnd' => $code
                    );
                }
            }
            
            if (!empty($areas)) {
                $schema['areaServed'] = $areas;
            }
        }
        
        // Add opening hours
        if (!empty($business['hours'])) {
            $opening_hours = array();
            foreach ($business['hours'] as $day => $hours) {
                if (!empty($hours['open']) && !empty($hours['close'])) {
                    $opening_hours[] = $day . ' ' . $hours['open'] . '-' . $hours['close'];
                }
            }
            if (!empty($opening_hours)) {
                $schema['openingHours'] = $opening_hours;
            }
        }
        
        return $schema;
    }
    
    public function generate_article_schema($post_id = 0) {
        if ($post_id === 0) {
            $post_id = get_the_ID();
        }
        
        if (!$post_id) {
            return array();
        }
        
        $post = get_post($post_id);
        $author = get_userdata($post->post_author);
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => get_the_title($post_id),
            'description' => get_the_excerpt($post_id),
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'author' => array(
                '@type' => 'Person',
                'name' => $author->display_name
            ),
            'publisher' => $this->get_organization_schema()
        );
        
        if (has_post_thumbnail($post_id)) {
            $schema['image'] = get_the_post_thumbnail_url($post_id, 'full');
        }
        
        return $schema;
    }
    
    public function generate_breadcrumb_schema() {
        if (!is_singular()) {
            return array();
        }
        
        $items = array();
        $position = 1;
        
        // Home
        $items[] = array(
            '@type' => 'ListItem',
            'position' => $position++,
            'name' => 'Home',
            'item' => home_url()
        );
        
        // Categories/Parents
        if (is_single()) {
            $categories = get_the_category();
            if (!empty($categories)) {
                $category = $categories[0];
                $items[] = array(
                    '@type' => 'ListItem',
                    'position' => $position++,
                    'name' => $category->name,
                    'item' => get_category_link($category->term_id)
                );
            }
        }
        
        // Current page
        $items[] = array(
            '@type' => 'ListItem',
            'position' => $position,
            'name' => get_the_title(),
            'item' => get_permalink()
        );
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items
        );
    }
    
    private function get_organization_schema() {
        $org = get_option('enhanced_schema_organization', array());
        
        return array(
            '@type' => 'Organization',
            'name' => !empty($org['name']) ? $org['name'] : get_bloginfo('name'),
            'url' => !empty($org['url']) ? $org['url'] : home_url(),
            'logo' => !empty($org['logo']) ? $org['logo'] : ''
        );
    }
}
