<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">
        <?php esc_html_e('Configure your organization information for schema markup.', 'enhanced-schema'); ?>
    </p>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_organization'); ?>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Basic Information', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="org_name"><?php esc_html_e('Organization Name', 'enhanced-schema'); ?> *</label>
                    </th>
                    <td>
                        <input type="text" name="org_name" id="org_name" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['name']) ? $organization['name'] : get_bloginfo('name')); ?>" required>
                        <p class="description"><?php esc_html_e('Your company or organization name', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_legal_name"><?php esc_html_e('Legal Name', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_legal_name" id="org_legal_name" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['legal_name']) ? $organization['legal_name'] : ''); ?>">
                        <p class="description"><?php esc_html_e('Official legal name if different from display name', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_url"><?php esc_html_e('Website URL', 'enhanced-schema'); ?> *</label>
                    </th>
                    <td>
                        <input type="url" name="org_url" id="org_url" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['url']) ? $organization['url'] : home_url()); ?>" required>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_logo"><?php esc_html_e('Logo URL', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="url" name="org_logo" id="org_logo" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['logo']) ? $organization['logo'] : ''); ?>">
                        <p class="description"><?php esc_html_e('Full URL to your organization logo', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_description"><?php esc_html_e('Description', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <textarea name="org_description" id="org_description" class="large-text" rows="4"><?php echo esc_textarea(isset($organization['description']) ? $organization['description'] : ''); ?></textarea>
                        <p class="description"><?php esc_html_e('Brief description of your organization', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Contact Information', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="org_email"><?php esc_html_e('Email', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="email" name="org_email" id="org_email" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['email']) ? $organization['email'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_phone"><?php esc_html_e('Phone', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="tel" name="org_phone" id="org_phone" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['phone']) ? $organization['phone'] : ''); ?>">
                        <p class="description"><?php esc_html_e('Format: +1-555-555-5555', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Address', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="org_street"><?php esc_html_e('Street Address', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_street" id="org_street" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['address']['street']) ? $organization['address']['street'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_city"><?php esc_html_e('City', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_city" id="org_city" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['address']['city']) ? $organization['address']['city'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_state"><?php esc_html_e('State/Province', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_state" id="org_state" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['address']['state']) ? $organization['address']['state'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_postal_code"><?php esc_html_e('Postal Code', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_postal_code" id="org_postal_code" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['address']['postal_code']) ? $organization['address']['postal_code'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_country"><?php esc_html_e('Country', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="org_country" id="org_country" class="regular-text" 
                               value="<?php echo esc_attr(isset($organization['address']['country']) ? $organization['address']['country'] : ''); ?>">
                        <p class="description"><?php esc_html_e('2-letter country code (e.g., US, CA, GB)', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Social Media', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="org_facebook"><?php esc_html_e('Facebook', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="url" name="org_facebook" id="org_facebook" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['social']['facebook']) ? $organization['social']['facebook'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_twitter"><?php esc_html_e('Twitter', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="url" name="org_twitter" id="org_twitter" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['social']['twitter']) ? $organization['social']['twitter'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_linkedin"><?php esc_html_e('LinkedIn', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="url" name="org_linkedin" id="org_linkedin" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['social']['linkedin']) ? $organization['social']['linkedin'] : ''); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="org_instagram"><?php esc_html_e('Instagram', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="url" name="org_instagram" id="org_instagram" class="regular-text" 
                               value="<?php echo esc_url(isset($organization['social']['instagram']) ? $organization['social']['instagram'] : ''); ?>">
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_organization_submit" class="button button-primary" value="<?php esc_attr_e('Save Organization Info', 'enhanced-schema'); ?>">
        </p>
    </form>
</div>
