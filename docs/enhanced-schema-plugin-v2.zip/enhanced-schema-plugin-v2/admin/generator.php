<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">
        <?php esc_html_e('Generate and preview schema markup for testing and validation.', 'enhanced-schema'); ?>
    </p>
    
    <div class="enhanced-schema-section">
        <h2><?php esc_html_e('Generate Schema', 'enhanced-schema'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="schema_type"><?php esc_html_e('Schema Type', 'enhanced-schema'); ?></label>
                </th>
                <td>
                    <select name="schema_type" id="schema_type" class="regular-text">
                        <option value="webpage"><?php esc_html_e('Webpage', 'enhanced-schema'); ?></option>
                        <option value="organization"><?php esc_html_e('Organization', 'enhanced-schema'); ?></option>
                        <option value="localbusiness"><?php esc_html_e('Local Business', 'enhanced-schema'); ?></option>
                        <option value="article"><?php esc_html_e('Article', 'enhanced-schema'); ?></option>
                        <option value="breadcrumb"><?php esc_html_e('Breadcrumb', 'enhanced-schema'); ?></option>
                    </select>
                </td>
            </tr>
            
            <tr id="post_id_row">
                <th scope="row">
                    <label for="post_id"><?php esc_html_e('Post/Page ID', 'enhanced-schema'); ?></label>
                </th>
                <td>
                    <input type="number" name="post_id" id="post_id" class="regular-text" value="" placeholder="<?php esc_attr_e('Leave blank for current page', 'enhanced-schema'); ?>">
                    <p class="description"><?php esc_html_e('Enter a post or page ID, or leave blank to use the homepage', 'enhanced-schema'); ?></p>
                </td>
            </tr>
        </table>
        
        <p>
            <button type="button" id="generate_schema_btn" class="button button-primary"><?php esc_html_e('Generate Schema', 'enhanced-schema'); ?></button>
        </p>
    </div>
    
    <div class="enhanced-schema-section" id="schema_output_section" style="display: none;">
        <h2><?php esc_html_e('Generated Schema', 'enhanced-schema'); ?></h2>
        
        <div id="schema_output" style="background: #f5f5f5; padding: 20px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 20px;">
            <pre id="schema_json" style="white-space: pre-wrap; word-wrap: break-word; font-family: monospace; font-size: 12px;"></pre>
        </div>
        
        <p>
            <button type="button" id="copy_schema_btn" class="button"><?php esc_html_e('Copy to Clipboard', 'enhanced-schema'); ?></button>
            <button type="button" id="validate_schema_btn" class="button"><?php esc_html_e('Validate Schema', 'enhanced-schema'); ?></button>
            <a href="https://search.google.com/test/rich-results" target="_blank" class="button"><?php esc_html_e('Test in Google Rich Results', 'enhanced-schema'); ?></a>
        </p>
        
        <div id="validation_result" style="margin-top: 20px;"></div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Show/hide post ID field based on schema type
    $('#schema_type').on('change', function() {
        var type = $(this).val();
        if (type === 'webpage' || type === 'article' || type === 'breadcrumb') {
            $('#post_id_row').show();
        } else {
            $('#post_id_row').hide();
        }
    });
    
    // Generate schema
    $('#generate_schema_btn').on('click', function() {
        var button = $(this);
        var schemaType = $('#schema_type').val();
        var postId = $('#post_id').val() || 0;
        
        button.prop('disabled', true).text('<?php esc_js(_e('Generating...', 'enhanced-schema')); ?>');
        
        $.ajax({
            url: enhancedSchemaAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'enhanced_schema_generate',
                nonce: enhancedSchemaAjax.nonce,
                schema_type: schemaType,
                post_id: postId
            },
            success: function(response) {
                if (response.success) {
                    $('#schema_json').text(response.data.json);
                    $('#schema_output_section').slideDown();
                    
                    // Scroll to output
                    $('html, body').animate({
                        scrollTop: $('#schema_output_section').offset().top - 100
                    }, 500);
                } else {
                    alert('<?php esc_js(_e('Error generating schema:', 'enhanced-schema')); ?> ' + response.data.message);
                }
            },
            error: function() {
                alert('<?php esc_js(_e('An error occurred while generating schema.', 'enhanced-schema')); ?>');
            },
            complete: function() {
                button.prop('disabled', false).text('<?php esc_js(_e('Generate Schema', 'enhanced-schema')); ?>');
            }
        });
    });
    
    // Copy to clipboard
    $('#copy_schema_btn').on('click', function() {
        var schemaText = $('#schema_json').text();
        
        // Create temporary textarea
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(schemaText).select();
        document.execCommand('copy');
        $temp.remove();
        
        // Show feedback
        var button = $(this);
        var originalText = button.text();
        button.text('<?php esc_js(_e('Copied!', 'enhanced-schema')); ?>');
        setTimeout(function() {
            button.text(originalText);
        }, 2000);
    });
    
    // Validate schema
    $('#validate_schema_btn').on('click', function() {
        var button = $(this);
        var schemaText = $('#schema_json').text();
        
        button.prop('disabled', true).text('<?php esc_js(_e('Validating...', 'enhanced-schema')); ?>');
        $('#validation_result').html('');
        
        $.ajax({
            url: enhancedSchemaAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'enhanced_schema_validate',
                nonce: enhancedSchemaAjax.nonce,
                schema: schemaText
            },
            success: function(response) {
                if (response.success) {
                    $('#validation_result').html('<div class="notice notice-success"><p><strong><?php esc_js(_e('Valid!', 'enhanced-schema')); ?></strong> ' + response.data.message + '</p></div>');
                } else {
                    $('#validation_result').html('<div class="notice notice-error"><p><strong><?php esc_js(_e('Invalid!', 'enhanced-schema')); ?></strong> ' + response.data.message + '</p></div>');
                }
            },
            error: function() {
                $('#validation_result').html('<div class="notice notice-error"><p><?php esc_js(_e('An error occurred while validating schema.', 'enhanced-schema')); ?></p></div>');
            },
            complete: function() {
                button.prop('disabled', false).text('<?php esc_js(_e('Validate Schema', 'enhanced-schema')); ?>');
            }
        });
    });
});
</script>
