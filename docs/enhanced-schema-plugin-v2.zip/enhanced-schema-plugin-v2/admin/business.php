<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">
        <?php esc_html_e('Configure your local business information and service area (georadius).', 'enhanced-schema'); ?>
    </p>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_business'); ?>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Business Information', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="business_type"><?php esc_html_e('Business Type', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <select name="business_type" id="business_type" class="regular-text">
                            <option value="LocalBusiness" <?php selected(isset($business['type']) ? $business['type'] : '', 'LocalBusiness'); ?>>Local Business</option>
                            <option value="HomeAndConstructionBusiness" <?php selected(isset($business['type']) ? $business['type'] : '', 'HomeAndConstructionBusiness'); ?>>Home & Construction</option>
                            <option value="HVACBusiness" <?php selected(isset($business['type']) ? $business['type'] : '', 'HVACBusiness'); ?>>HVAC Business</option>
                            <option value="Electrician" <?php selected(isset($business['type']) ? $business['type'] : '', 'Electrician'); ?>>Electrician</option>
                            <option value="Plumber" <?php selected(isset($business['type']) ? $business['type'] : '', 'Plumber'); ?>>Plumber</option>
                            <option value="GeneralContractor" <?php selected(isset($business['type']) ? $business['type'] : '', 'GeneralContractor'); ?>>General Contractor</option>
                            <option value="Locksmith" <?php selected(isset($business['type']) ? $business['type'] : '', 'Locksmith'); ?>>Locksmith</option>
                            <option value="MovingCompany" <?php selected(isset($business['type']) ? $business['type'] : '', 'MovingCompany'); ?>>Moving Company</option>
                            <option value="RoofingContractor" <?php selected(isset($business['type']) ? $business['type'] : '', 'RoofingContractor'); ?>>Roofing Contractor</option>
                            <option value="ProfessionalService" <?php selected(isset($business['type']) ? $business['type'] : '', 'ProfessionalService'); ?>>Professional Service</option>
                            <option value="LegalService" <?php selected(isset($business['type']) ? $business['type'] : '', 'LegalService'); ?>>Legal Service</option>
                            <option value="AccountingService" <?php selected(isset($business['type']) ? $business['type'] : '', 'AccountingService'); ?>>Accounting Service</option>
                            <option value="HealthAndBeautyBusiness" <?php selected(isset($business['type']) ? $business['type'] : '', 'HealthAndBeautyBusiness'); ?>>Health & Beauty</option>
                            <option value="AutoRepair" <?php selected(isset($business['type']) ? $business['type'] : '', 'AutoRepair'); ?>>Auto Repair</option>
                            <option value="FoodEstablishment" <?php selected(isset($business['type']) ? $business['type'] : '', 'FoodEstablishment'); ?>>Food Establishment</option>
                            <option value="Restaurant" <?php selected(isset($business['type']) ? $business['type'] : '', 'Restaurant'); ?>>Restaurant</option>
                        </select>
                        <p class="description"><?php esc_html_e('Select the most specific business type that applies', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_name"><?php esc_html_e('Business Name', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="business_name" id="business_name" class="regular-text" 
                               value="<?php echo esc_attr(isset($business['name']) ? $business['name'] : get_bloginfo('name')); ?>">
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_price_range"><?php esc_html_e('Price Range', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="business_price_range" id="business_price_range" class="regular-text" 
                               value="<?php echo esc_attr(isset($business['price_range']) ? $business['price_range'] : ''); ?>" 
                               placeholder="$$">
                        <p class="description"><?php esc_html_e('e.g., $, $$, $$$, or $$$$', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Location & Georadius', 'enhanced-schema'); ?></h2>
            <p class="description"><?php esc_html_e('Define your service area using coordinates and postal codes.', 'enhanced-schema'); ?></p>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="business_latitude"><?php esc_html_e('Latitude', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="business_latitude" id="business_latitude" class="regular-text" 
                               value="<?php echo esc_attr(isset($business['geo']['latitude']) ? $business['geo']['latitude'] : ''); ?>" 
                               placeholder="40.7128">
                        <p class="description"><?php esc_html_e('Decimal degrees (e.g., 40.7128)', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_longitude"><?php esc_html_e('Longitude', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="business_longitude" id="business_longitude" class="regular-text" 
                               value="<?php echo esc_attr(isset($business['geo']['longitude']) ? $business['geo']['longitude'] : ''); ?>" 
                               placeholder="-74.0060">
                        <p class="description"><?php esc_html_e('Decimal degrees (e.g., -74.0060)', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_radius"><?php esc_html_e('Service Radius', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="business_radius" id="business_radius" class="regular-text" 
                               value="<?php echo esc_attr(isset($business['geo']['radius']) ? $business['geo']['radius'] : ''); ?>" 
                               placeholder="50">
                        <p class="description"><?php esc_html_e('Service radius in miles from your location', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_postal_codes"><?php esc_html_e('Postal Codes Served', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <textarea name="business_postal_codes" id="business_postal_codes" class="large-text" rows="5"><?php echo esc_textarea(isset($business['geo']['postal_codes']) ? $business['geo']['postal_codes'] : ''); ?></textarea>
                        <p class="description"><?php esc_html_e('Comma-separated list of postal codes you serve (e.g., 10001, 10002, 10003)', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="business_service_area"><?php esc_html_e('Service Area Description', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <textarea name="business_service_area" id="business_service_area" class="large-text" rows="3"><?php echo esc_textarea(isset($business['service_area']) ? $business['service_area'] : ''); ?></textarea>
                        <p class="description"><?php esc_html_e('Human-readable description of your service area (e.g., "Greater New York City Area")', 'enhanced-schema'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Business Hours', 'enhanced-schema'); ?></h2>
            <p class="description"><?php esc_html_e('Specify your operating hours for each day of the week.', 'enhanced-schema'); ?></p>
            
            <table class="form-table">
                <?php
                $days = array(
                    'Monday' => 'Mo',
                    'Tuesday' => 'Tu',
                    'Wednesday' => 'We',
                    'Thursday' => 'Th',
                    'Friday' => 'Fr',
                    'Saturday' => 'Sa',
                    'Sunday' => 'Su'
                );
                
                foreach ($days as $day => $abbr) {
                    $open = isset($business['hours'][$abbr]['open']) ? $business['hours'][$abbr]['open'] : '';
                    $close = isset($business['hours'][$abbr]['close']) ? $business['hours'][$abbr]['close'] : '';
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html($day); ?></th>
                        <td>
                            <input type="time" name="business_hours[<?php echo esc_attr($abbr); ?>][open]" value="<?php echo esc_attr($open); ?>" style="width: 120px;">
                            <span> to </span>
                            <input type="time" name="business_hours[<?php echo esc_attr($abbr); ?>][close]" value="<?php echo esc_attr($close); ?>" style="width: 120px;">
                            <span class="description"><?php esc_html_e('Leave blank if closed', 'enhanced-schema'); ?></span>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_business_submit" class="button button-primary" value="<?php esc_attr_e('Save Business Info', 'enhanced-schema'); ?>">
        </p>
    </form>
</div>
