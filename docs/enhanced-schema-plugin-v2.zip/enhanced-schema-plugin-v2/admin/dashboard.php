<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">
        <?php esc_html_e('Comprehensive schema markup for improved SEO and rich search results', 'enhanced-schema'); ?>
    </p>

    <div class="enhanced-schema-dashboard">
        <!-- Status Cards -->
        <div class="enhanced-schema-cards">
            <div class="enhanced-schema-card">
                <h3><?php esc_html_e('Schema Status', 'enhanced-schema'); ?></h3>
                <div class="enhanced-schema-stat">
                    <span class="stat-value <?php echo $enabled ? 'active' : 'inactive'; ?>">
                        <?php echo $enabled ? esc_html__('Active', 'enhanced-schema') : esc_html__('Inactive', 'enhanced-schema'); ?>
                    </span>
                    <p class="stat-description">
                        <?php echo $enabled 
                            ? esc_html__('Schema generation is currently enabled on your site.', 'enhanced-schema')
                            : esc_html__('Schema generation is currently disabled.', 'enhanced-schema'); ?>
                    </p>
                </div>
            </div>

            <div class="enhanced-schema-card">
                <h3><?php esc_html_e('Enabled Schema Types', 'enhanced-schema'); ?></h3>
                <div class="enhanced-schema-stat">
                    <span class="stat-value"><?php echo $enabled_count; ?></span>
                    <p class="stat-description">
                        <?php esc_html_e('Number of schema types currently active.', 'enhanced-schema'); ?>
                    </p>
                </div>
            </div>

            <div class="enhanced-schema-card">
                <h3><?php esc_html_e('Cached Entities', 'enhanced-schema'); ?></h3>
                <div class="enhanced-schema-stat">
                    <span class="stat-value"><?php echo count($cached_entities); ?></span>
                    <p class="stat-description">
                        <?php esc_html_e('Entities detected and cached for faster generation.', 'enhanced-schema'); ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Quick Start Guide -->
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Quick Start Guide', 'enhanced-schema'); ?></h2>
            <ol class="enhanced-schema-steps">
                <li>
                    <strong><?php esc_html_e('Configure Settings:', 'enhanced-schema'); ?></strong>
                    <?php esc_html_e('Go to Settings to enable schema types and configure options.', 'enhanced-schema'); ?>
                </li>
                <li>
                    <strong><?php esc_html_e('Add Organization Info:', 'enhanced-schema'); ?></strong>
                    <?php esc_html_e('Fill in your organization details for complete schema markup.', 'enhanced-schema'); ?>
                </li>
                <li>
                    <strong><?php esc_html_e('Set Up Local Business:', 'enhanced-schema'); ?></strong>
                    <?php esc_html_e('If applicable, configure your business information and georadius.', 'enhanced-schema'); ?>
                </li>
                <li>
                    <strong><?php esc_html_e('Test Schema:', 'enhanced-schema'); ?></strong>
                    <?php esc_html_e('Use the Schema Generator to preview and validate your schema.', 'enhanced-schema'); ?>
                </li>
                <li>
                    <strong><?php esc_html_e('Verify in Google:', 'enhanced-schema'); ?></strong>
                    <?php esc_html_e('Test your pages with Google\'s Rich Results Test tool.', 'enhanced-schema'); ?>
                </li>
            </ol>
        </div>

        <!-- Active Schema Types Table -->
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Active Schema Types', 'enhanced-schema'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Schema Type', 'enhanced-schema'); ?></th>
                        <th><?php esc_html_e('Status', 'enhanced-schema'); ?></th>
                        <th><?php esc_html_e('Description', 'enhanced-schema'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $all_schema_types = array(
                        'webpage' => array(
                            'label' => __('Webpage Schema', 'enhanced-schema'),
                            'description' => __('Automatic schema for all pages and posts', 'enhanced-schema')
                        ),
                        'organization' => array(
                            'label' => __('Organization Schema', 'enhanced-schema'),
                            'description' => __('Company information and branding', 'enhanced-schema')
                        ),
                        'localbusiness' => array(
                            'label' => __('Local Business Schema', 'enhanced-schema'),
                            'description' => __('Local business with georadius support', 'enhanced-schema')
                        ),
                        'video' => array(
                            'label' => __('Video Schema', 'enhanced-schema'),
                            'description' => __('Automatic detection of embedded videos', 'enhanced-schema')
                        ),
                        'faq' => array(
                            'label' => __('FAQ Schema', 'enhanced-schema'),
                            'description' => __('Automatic FAQ detection from content', 'enhanced-schema')
                        ),
                    );

                    foreach ($all_schema_types as $type => $data) {
                        $is_enabled = isset($schema_types[$type]) && $schema_types[$type];
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html($data['label']); ?></strong></td>
                            <td>
                                <span class="enhanced-schema-status <?php echo $is_enabled ? 'enabled' : 'disabled'; ?>">
                                    <?php echo $is_enabled ? '✓ ' . esc_html__('Enabled', 'enhanced-schema') : '✗ ' . esc_html__('Disabled', 'enhanced-schema'); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($data['description']); ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Activity -->
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Recent Activity', 'enhanced-schema'); ?></h2>
            <p><?php esc_html_e('Schema generation is automatic. Check individual pages to see generated schema or use the Schema Generator tool.', 'enhanced-schema'); ?></p>
        </div>
    </div>
</div>
