/**
 * Enhanced Schema Plugin - Admin JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Initialize admin functionality
        initSchemaGenerator();
        initBusinessHours();
    });
    
    /**
     * Initialize schema generator functionality
     */
    function initSchemaGenerator() {
        // Already handled in generator.php template
    }
    
    /**
     * Initialize business hours functionality
     */
    function initBusinessHours() {
        // Add "Copy to all days" functionality if needed
        $('.copy-hours-btn').on('click', function(e) {
            e.preventDefault();
            
            var $firstOpen = $('input[name="business_hours[Mo][open]"]');
            var $firstClose = $('input[name="business_hours[Mo][close]"]');
            
            if ($firstOpen.val() && $firstClose.val()) {
                var openTime = $firstOpen.val();
                var closeTime = $firstClose.val();
                
                $('input[name*="[open]"]').val(openTime);
                $('input[name*="[close]"]').val(closeTime);
                
                alert('Hours copied to all days!');
            } else {
                alert('Please set Monday hours first.');
            }
        });
    }
    
})(jQuery);
