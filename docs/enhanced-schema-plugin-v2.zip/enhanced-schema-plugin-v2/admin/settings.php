<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

$enabled = isset($settings['enabled']) ? $settings['enabled'] : true;
$schema_types = isset($settings['schema_types']) ? $settings['schema_types'] : array();
$auto_detect = isset($settings['auto_detect_entities']) ? $settings['auto_detect_entities'] : true;
$cache_entities = isset($settings['cache_entities']) ? $settings['cache_entities'] : true;
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_settings'); ?>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('General Settings', 'enhanced-schema'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="enabled"><?php esc_html_e('Enable Schema Generation', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="enabled" id="enabled" value="1" <?php checked($enabled, true); ?>>
                            <?php esc_html_e('Enable automatic schema generation on your site', 'enhanced-schema'); ?>
                        </label>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="auto_detect_entities"><?php esc_html_e('Auto-Detect Entities', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="auto_detect_entities" id="auto_detect_entities" value="1" <?php checked($auto_detect, true); ?>>
                            <?php esc_html_e('Automatically detect entities from content using Wikipedia/Wikidata', 'enhanced-schema'); ?>
                        </label>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="cache_entities"><?php esc_html_e('Cache Entities', 'enhanced-schema'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="cache_entities" id="cache_entities" value="1" <?php checked($cache_entities, true); ?>>
                            <?php esc_html_e('Cache detected entities for faster page load times', 'enhanced-schema'); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="enhanced-schema-section">
            <h2><?php esc_html_e('Schema Types', 'enhanced-schema'); ?></h2>
            <p class="description"><?php esc_html_e('Select which schema types to enable on your site.', 'enhanced-schema'); ?></p>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Enabled Schema Types', 'enhanced-schema'); ?></th>
                    <td>
                        <fieldset>
                            <label>
                                <input type="checkbox" name="schema_types[webpage]" value="1" <?php checked(isset($schema_types['webpage']) && $schema_types['webpage'], true); ?>>
                                <strong><?php esc_html_e('Webpage Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Basic webpage schema for all pages and posts', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[organization]" value="1" <?php checked(isset($schema_types['organization']) && $schema_types['organization'], true); ?>>
                                <strong><?php esc_html_e('Organization Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Company/organization information', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[localbusiness]" value="1" <?php checked(isset($schema_types['localbusiness']) && $schema_types['localbusiness'], true); ?>>
                                <strong><?php esc_html_e('Local Business Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Local business with georadius and service area', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[article]" value="1" <?php checked(isset($schema_types['article']) && $schema_types['article'], true); ?>>
                                <strong><?php esc_html_e('Article Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Article schema for blog posts', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[breadcrumb]" value="1" <?php checked(isset($schema_types['breadcrumb']) && $schema_types['breadcrumb'], true); ?>>
                                <strong><?php esc_html_e('Breadcrumb Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Breadcrumb navigation schema', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[video]" value="1" <?php checked(isset($schema_types['video']) && $schema_types['video'], true); ?>>
                                <strong><?php esc_html_e('Video Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Automatic detection of embedded videos', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[faq]" value="1" <?php checked(isset($schema_types['faq']) && $schema_types['faq'], true); ?>>
                                <strong><?php esc_html_e('FAQ Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Automatic FAQ detection from content', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[product]" value="1" <?php checked(isset($schema_types['product']) && $schema_types['product'], true); ?>>
                                <strong><?php esc_html_e('Product Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Product schema for WooCommerce and other e-commerce', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[event]" value="1" <?php checked(isset($schema_types['event']) && $schema_types['event'], true); ?>>
                                <strong><?php esc_html_e('Event Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Event schema for calendar and event posts', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[recipe]" value="1" <?php checked(isset($schema_types['recipe']) && $schema_types['recipe'], true); ?>>
                                <strong><?php esc_html_e('Recipe Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Recipe schema for food and cooking sites', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[person]" value="1" <?php checked(isset($schema_types['person']) && $schema_types['person'], true); ?>>
                                <strong><?php esc_html_e('Person Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Person schema for author profiles', 'enhanced-schema'); ?></p>
                            </label>
                            <br><br>
                            
                            <label>
                                <input type="checkbox" name="schema_types[review]" value="1" <?php checked(isset($schema_types['review']) && $schema_types['review'], true); ?>>
                                <strong><?php esc_html_e('Review Schema', 'enhanced-schema'); ?></strong>
                                <p class="description"><?php esc_html_e('Review and rating schema', 'enhanced-schema'); ?></p>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_settings_submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'enhanced-schema'); ?>">
        </p>
    </form>
</div>
