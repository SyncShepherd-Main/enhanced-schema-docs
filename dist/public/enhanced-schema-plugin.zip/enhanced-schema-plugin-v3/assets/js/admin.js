/**
 * Enhanced Schema Plugin - Admin JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Media uploader for logo
        if (typeof wp !== 'undefined' && typeof wp.media !== 'undefined') {
            $('#upload_logo_button').on('click', function(e) {
                e.preventDefault();
                
                var mediaUploader = wp.media({
                    title: 'Select Logo',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false
                });
                
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#organization_logo').val(attachment.url);
                    
                    if ($('.logo-preview').length) {
                        $('.logo-preview img').attr('src', attachment.url);
                    } else {
                        $('#organization_logo').after(
                            '<div class="logo-preview"><img src="' + attachment.url + '" alt="Logo Preview"></div>'
                        );
                    }
                });
                
                mediaUploader.open();
            });
        }
        
        // Form validation
        $('form').on('submit', function(e) {
            var requiredFields = $(this).find('[required]');
            var hasErrors = false;
            
            requiredFields.each(function() {
                if (!$(this).val()) {
                    hasErrors = true;
                    $(this).css('border-color', '#dc3232');
                } else {
                    $(this).css('border-color', '');
                }
            });
            
            if (hasErrors) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
        });
        
        // Clear validation errors on input
        $('[required]').on('input change', function() {
            if ($(this).val()) {
                $(this).css('border-color', '');
            }
        });
        
        // Schema generator
        $('#generate_schema').on('click', function() {
            var url = $('#test_url').val();
            
            if (!url) {
                alert('Please enter a URL');
                return;
            }
            
            $('#schema_output').hide();
            $('#schema_error').hide();
            $('#schema_loading').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'enhanced_schema_generate',
                    url: url,
                    nonce: $('#schema_nonce').val()
                },
                success: function(response) {
                    $('#schema_loading').hide();
                    
                    if (response.success) {
                        $('#schema_code').text(JSON.stringify(response.data, null, 2));
                        $('#schema_output').show();
                    } else {
                        $('#schema_error p').text(response.data || 'Error generating schema');
                        $('#schema_error').show();
                    }
                },
                error: function() {
                    $('#schema_loading').hide();
                    $('#schema_error p').text('Network error. Please try again.');
                    $('#schema_error').show();
                }
            });
        });
        
        // Copy schema to clipboard
        $('#copy_schema').on('click', function() {
            var code = $('#schema_code').text();
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(code).then(function() {
                    alert('Schema copied to clipboard!');
                }).catch(function() {
                    fallbackCopyTextToClipboard(code);
                });
            } else {
                fallbackCopyTextToClipboard(code);
            }
        });
        
        // Fallback copy function
        function fallbackCopyTextToClipboard(text) {
            var textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.top = '0';
            textArea.style.left = '0';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                alert('Schema copied to clipboard!');
            } catch (err) {
                alert('Failed to copy schema. Please copy manually.');
            }
            
            document.body.removeChild(textArea);
        }
        
        // Postal code validation
        $('#georadius_postal_codes').on('blur', function() {
            var codes = $(this).val().split('\n');
            var validCodes = [];
            
            codes.forEach(function(code) {
                code = code.trim();
                if (code && /^\d{5}(-\d{4})?$/.test(code)) {
                    validCodes.push(code);
                }
            });
            
            if (validCodes.length !== codes.filter(function(c) { return c.trim(); }).length) {
                if (confirm('Some postal codes appear to be invalid. Would you like to remove them?')) {
                    $(this).val(validCodes.join('\n'));
                }
            }
        });
    });
    
})(jQuery);
