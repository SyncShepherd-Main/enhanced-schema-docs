<?php
/**
 * Dashboard Template
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">Comprehensive schema markup for improved SEO and rich search results</p>
    
    <div class="enhanced-schema-dashboard">
        <div class="enhanced-schema-stats">
            <div class="stat-box">
                <h3>Schema Status</h3>
                <div class="stat-value <?php echo $schema_enabled ? 'active' : 'inactive'; ?>">
                    <?php echo $schema_enabled ? 'Active' : 'Inactive'; ?>
                </div>
                <p class="stat-description">
                    <?php echo $schema_enabled ? 'Schema generation is currently enabled on your site.' : 'Schema generation is currently disabled.'; ?>
                </p>
            </div>
            
            <div class="stat-box">
                <h3>Enabled Schema Types</h3>
                <div class="stat-value"><?php echo esc_html($enabled_count); ?></div>
                <p class="stat-description">Number of schema types currently active.</p>
            </div>
            
            <div class="stat-box">
                <h3>Cached Entities</h3>
                <div class="stat-value"><?php echo esc_html($entity_count); ?></div>
                <p class="stat-description">Entities detected and cached for faster generation.</p>
            </div>
        </div>
        
        <div class="enhanced-schema-guide">
            <h2>Quick Start Guide</h2>
            <ol>
                <li><strong>Configure Settings:</strong> Go to <a href="<?php echo admin_url('admin.php?page=enhanced-schema-settings'); ?>">General Settings</a> to enable schema types and configure options.</li>
                <li><strong>Add Organization Info:</strong> Fill in your organization details in <a href="<?php echo admin_url('admin.php?page=enhanced-schema-organization'); ?>">Organization</a> for complete schema markup.</li>
                <li><strong>Set Up Local Business:</strong> If applicable, configure your business information in <a href="<?php echo admin_url('admin.php?page=enhanced-schema-business'); ?>">Local Business</a>.</li>
                <li><strong>Test Schema:</strong> Use the <a href="<?php echo admin_url('admin.php?page=enhanced-schema-generator'); ?>">Schema Generator</a> to preview and validate your schema.</li>
                <li><strong>Verify in Google:</strong> Test your pages with <a href="https://search.google.com/test/rich-results" target="_blank">Google's Rich Results Test</a> tool.</li>
            </ol>
        </div>
        
        <div class="enhanced-schema-types">
            <h2>Active Schema Types</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Schema Type</th>
                        <th>Status</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $schema_types_info = array(
                        'webpage' => array('name' => 'Webpage Schema', 'desc' => 'Automatic schema for all pages and posts'),
                        'organization' => array('name' => 'Organization Schema', 'desc' => 'Company information and branding'),
                        'local_business' => array('name' => 'Local Business Schema', 'desc' => 'Local business with georadius support'),
                        'video' => array('name' => 'Video Schema', 'desc' => 'Automatic detection of embedded videos'),
                        'faq' => array('name' => 'FAQ Schema', 'desc' => 'Automatic FAQ detection from content'),
                        'article' => array('name' => 'Article Schema', 'desc' => 'Blog posts and articles'),
                        'product' => array('name' => 'Product Schema', 'desc' => 'E-commerce products'),
                        'event' => array('name' => 'Event Schema', 'desc' => 'Events and happenings'),
                        'recipe' => array('name' => 'Recipe Schema', 'desc' => 'Cooking recipes'),
                        'review' => array('name' => 'Review Schema', 'desc' => 'Product and service reviews'),
                        'howto' => array('name' => 'How-To Schema', 'desc' => 'Step-by-step guides'),
                        'breadcrumb' => array('name' => 'Breadcrumb Schema', 'desc' => 'Navigation breadcrumbs')
                    );
                    
                    foreach ($schema_types_info as $key => $info) {
                        $enabled = isset($schema_types[$key]) && $schema_types[$key];
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html($info['name']); ?></strong></td>
                            <td>
                                <?php if ($enabled): ?>
                                    <span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span> Enabled
                                <?php else: ?>
                                    <span class="dashicons dashicons-dismiss" style="color: #dc3232;"></span> Disabled
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($info['desc']); ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <div class="enhanced-schema-activity">
            <h2>Recent Activity</h2>
            <p>Schema generation is automatic. Check individual pages to see generated schema or use the Schema Generator tool.</p>
        </div>
    </div>
</div>
