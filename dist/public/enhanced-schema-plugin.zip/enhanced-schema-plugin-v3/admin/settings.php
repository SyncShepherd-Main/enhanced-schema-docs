<?php
/**
 * General Settings Template
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['enhanced_schema_settings_submit'])) {
    check_admin_referer('enhanced_schema_settings_save');
    
    update_option('enhanced_schema_schema_enabled', isset($_POST['schema_enabled']) ? '1' : '0');
    
    $schema_types = array();
    if (isset($_POST['schema_types']) && is_array($_POST['schema_types'])) {
        foreach ($_POST['schema_types'] as $type => $value) {
            $schema_types[$type] = '1';
        }
    }
    update_option('enhanced_schema_schema_types', $schema_types);
    
    update_option('enhanced_schema_entity_cache_enabled', isset($_POST['entity_cache_enabled']) ? '1' : '0');
    update_option('enhanced_schema_entity_cache_duration', sanitize_text_field($_POST['entity_cache_duration']));
    update_option('enhanced_schema_google_places_api_key', sanitize_text_field($_POST['google_places_api_key']));
    update_option('enhanced_schema_openai_api_key', sanitize_text_field($_POST['openai_api_key']));
    
    echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
}

// Get current values
$schema_enabled = get_option('enhanced_schema_schema_enabled', '1');
$schema_types = get_option('enhanced_schema_schema_types', array());
$entity_cache_enabled = get_option('enhanced_schema_entity_cache_enabled', '1');
$entity_cache_duration = get_option('enhanced_schema_entity_cache_duration', '7');
$google_places_api_key = get_option('enhanced_schema_google_places_api_key', '');
$openai_api_key = get_option('enhanced_schema_openai_api_key', '');
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_settings_save'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">Enable Schema Generation</th>
                <td>
                    <label>
                        <input type="checkbox" name="schema_enabled" value="1" <?php checked($schema_enabled, '1'); ?>>
                        Enable automatic schema generation on your site
                    </label>
                </td>
            </tr>
        </table>
        
        <h2>Schema Types</h2>
        <p class="description">Select which schema types to enable on your site.</p>
        
        <table class="form-table">
            <?php
            $schema_types_info = array(
                'webpage' => 'Webpage Schema - Automatic schema for all pages and posts',
                'organization' => 'Organization Schema - Company information and branding',
                'local_business' => 'Local Business Schema - Local business with georadius support',
                'video' => 'Video Schema - Automatic detection of embedded videos',
                'faq' => 'FAQ Schema - Automatic FAQ detection from content',
                'article' => 'Article Schema - Blog posts and articles',
                'product' => 'Product Schema - E-commerce products',
                'event' => 'Event Schema - Events and happenings',
                'recipe' => 'Recipe Schema - Cooking recipes',
                'review' => 'Review Schema - Product and service reviews',
                'howto' => 'How-To Schema - Step-by-step guides',
                'breadcrumb' => 'Breadcrumb Schema - Navigation breadcrumbs'
            );
            
            foreach ($schema_types_info as $key => $label) {
                $checked = isset($schema_types[$key]) && $schema_types[$key];
                ?>
                <tr>
                    <th scope="row"><?php echo esc_html(explode(' - ', $label)[0]); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="schema_types[<?php echo esc_attr($key); ?>]" value="1" <?php checked($checked, true); ?>>
                            <?php echo esc_html(explode(' - ', $label)[1]); ?>
                        </label>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
        
        <h2>Entity Cache Settings</h2>
        <p class="description">Configure entity detection and caching for improved performance.</p>
        
        <table class="form-table">
            <tr>
                <th scope="row">Enable Entity Caching</th>
                <td>
                    <label>
                        <input type="checkbox" name="entity_cache_enabled" value="1" <?php checked($entity_cache_enabled, '1'); ?>>
                        Cache detected entities from Wikipedia/Wikidata
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row">Cache Duration</th>
                <td>
                    <input type="number" name="entity_cache_duration" value="<?php echo esc_attr($entity_cache_duration); ?>" min="1" max="365" class="small-text">
                    days
                    <p class="description">How long to cache entity data before refreshing.</p>
                </td>
            </tr>
        </table>
        
        <h2>API Settings</h2>
        <p class="description">Configure API keys for enhanced functionality.</p>
        
        <table class="form-table">
            <tr>
                <th scope="row">Google Places API Key</th>
                <td>
                    <input type="text" name="google_places_api_key" value="<?php echo esc_attr($google_places_api_key); ?>" class="regular-text">
                    <p class="description">Required for georadius and location features. <a href="https://developers.google.com/maps/documentation/places/web-service/get-api-key" target="_blank">Get API Key</a></p>
                </td>
            </tr>
            <tr>
                <th scope="row">OpenAI API Key</th>
                <td>
                    <input type="text" name="openai_api_key" value="<?php echo esc_attr($openai_api_key); ?>" class="regular-text">
                    <p class="description">Optional: For AI-powered content generation and enhancement. <a href="https://platform.openai.com/api-keys" target="_blank">Get API Key</a></p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_settings_submit" class="button button-primary" value="Save Settings">
        </p>
    </form>
</div>
