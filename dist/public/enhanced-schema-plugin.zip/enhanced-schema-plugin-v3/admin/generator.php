<?php
/**
 * Schema Generator Template
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">Preview and test your schema markup before it goes live.</p>
    
    <div class="schema-generator">
        <h2>Test Schema Generation</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="test_url">Page URL</label>
                </th>
                <td>
                    <input type="url" id="test_url" value="<?php echo esc_url(home_url('/')); ?>" class="large-text">
                    <button type="button" id="generate_schema" class="button button-primary">Generate Schema</button>
                    <p class="description">Enter a URL from your site to preview its schema markup.</p>
                </td>
            </tr>
        </table>
        
        <div id="schema_output" style="display: none; margin-top: 20px;">
            <h3>Generated Schema</h3>
            <div class="schema-actions" style="margin-bottom: 10px;">
                <button type="button" id="copy_schema" class="button">Copy to Clipboard</button>
                <a href="https://search.google.com/test/rich-results" target="_blank" class="button">Test in Google</a>
                <a href="https://validator.schema.org/" target="_blank" class="button">Validate Schema</a>
            </div>
            <pre id="schema_code" style="background: #f5f5f5; padding: 15px; border: 1px solid #ddd; overflow-x: auto; max-height: 500px;"></pre>
        </div>
        
        <div id="schema_loading" style="display: none; margin-top: 20px;">
            <p><span class="spinner is-active" style="float: none;"></span> Generating schema...</p>
        </div>
        
        <div id="schema_error" style="display: none; margin-top: 20px;" class="notice notice-error">
            <p></p>
        </div>
    </div>
    
    <div class="schema-info" style="margin-top: 40px;">
        <h2>Schema Validation Tools</h2>
        <p>Use these tools to validate and test your schema markup:</p>
        <ul>
            <li><strong><a href="https://search.google.com/test/rich-results" target="_blank">Google Rich Results Test</a></strong> - Test how your page appears in Google search results</li>
            <li><strong><a href="https://validator.schema.org/" target="_blank">Schema.org Validator</a></strong> - Validate your schema markup against Schema.org standards</li>
            <li><strong><a href="https://search.google.com/search-console" target="_blank">Google Search Console</a></strong> - Monitor your rich results performance</li>
        </ul>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#generate_schema').click(function() {
        var url = $('#test_url').val();
        
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        $('#schema_output').hide();
        $('#schema_error').hide();
        $('#schema_loading').show();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'enhanced_schema_generate',
                url: url,
                nonce: '<?php echo wp_create_nonce('enhanced_schema_generate'); ?>'
            },
            success: function(response) {
                $('#schema_loading').hide();
                
                if (response.success) {
                    $('#schema_code').text(JSON.stringify(response.data, null, 2));
                    $('#schema_output').show();
                } else {
                    $('#schema_error p').text(response.data || 'Error generating schema');
                    $('#schema_error').show();
                }
            },
            error: function() {
                $('#schema_loading').hide();
                $('#schema_error p').text('Network error. Please try again.');
                $('#schema_error').show();
            }
        });
    });
    
    $('#copy_schema').click(function() {
        var code = $('#schema_code').text();
        navigator.clipboard.writeText(code).then(function() {
            alert('Schema copied to clipboard!');
        });
    });
});
</script>
