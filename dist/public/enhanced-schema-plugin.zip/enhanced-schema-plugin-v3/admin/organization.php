<?php
/**
 * Organization Settings Template
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['enhanced_schema_organization_submit'])) {
    check_admin_referer('enhanced_schema_organization_save');
    
    update_option('enhanced_schema_organization_name', sanitize_text_field($_POST['organization_name']));
    update_option('enhanced_schema_organization_url', esc_url_raw($_POST['organization_url']));
    update_option('enhanced_schema_organization_logo', esc_url_raw($_POST['organization_logo']));
    update_option('enhanced_schema_organization_description', sanitize_textarea_field($_POST['organization_description']));
    update_option('enhanced_schema_organization_phone', sanitize_text_field($_POST['organization_phone']));
    update_option('enhanced_schema_organization_email', sanitize_email($_POST['organization_email']));
    
    echo '<div class="notice notice-success is-dismissible"><p>Organization settings saved successfully!</p></div>';
}

// Get current values
$organization_name = get_option('enhanced_schema_organization_name', get_bloginfo('name'));
$organization_url = get_option('enhanced_schema_organization_url', get_site_url());
$organization_logo = get_option('enhanced_schema_organization_logo', '');
$organization_description = get_option('enhanced_schema_organization_description', get_bloginfo('description'));
$organization_phone = get_option('enhanced_schema_organization_phone', '');
$organization_email = get_option('enhanced_schema_organization_email', get_bloginfo('admin_email'));
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">Configure your organization information for schema markup.</p>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_organization_save'); ?>
        
        <h2>Basic Information</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="organization_name">Organization Name *</label>
                </th>
                <td>
                    <input type="text" name="organization_name" id="organization_name" value="<?php echo esc_attr($organization_name); ?>" class="regular-text" required>
                    <p class="description">The official name of your organization.</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="organization_url">Website URL *</label>
                </th>
                <td>
                    <input type="url" name="organization_url" id="organization_url" value="<?php echo esc_attr($organization_url); ?>" class="regular-text" required>
                    <p class="description">Your organization's main website URL.</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="organization_logo">Logo URL</label>
                </th>
                <td>
                    <input type="url" name="organization_logo" id="organization_logo" value="<?php echo esc_attr($organization_logo); ?>" class="regular-text">
                    <button type="button" class="button" id="upload_logo_button">Upload Logo</button>
                    <p class="description">URL to your organization's logo image. Recommended size: 600x60px or larger.</p>
                    <?php if ($organization_logo): ?>
                        <div class="logo-preview">
                            <img src="<?php echo esc_url($organization_logo); ?>" alt="Logo Preview" style="max-width: 300px; margin-top: 10px;">
                        </div>
                    <?php endif; ?>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="organization_description">Description</label>
                </th>
                <td>
                    <textarea name="organization_description" id="organization_description" rows="4" class="large-text"><?php echo esc_textarea($organization_description); ?></textarea>
                    <p class="description">A brief description of your organization.</p>
                </td>
            </tr>
        </table>
        
        <h2>Contact Information</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="organization_phone">Phone Number</label>
                </th>
                <td>
                    <input type="tel" name="organization_phone" id="organization_phone" value="<?php echo esc_attr($organization_phone); ?>" class="regular-text">
                    <p class="description">Main contact phone number (e.g., +1-555-555-5555).</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="organization_email">Email Address</label>
                </th>
                <td>
                    <input type="email" name="organization_email" id="organization_email" value="<?php echo esc_attr($organization_email); ?>" class="regular-text">
                    <p class="description">Main contact email address.</p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_organization_submit" class="button button-primary" value="Save Organization Settings">
        </p>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    $('#upload_logo_button').click(function(e) {
        e.preventDefault();
        var image = wp.media({
            title: 'Upload Logo',
            multiple: false
        }).open().on('select', function(){
            var uploaded_image = image.state().get('selection').first();
            var image_url = uploaded_image.toJSON().url;
            $('#organization_logo').val(image_url);
            if ($('.logo-preview').length) {
                $('.logo-preview img').attr('src', image_url);
            } else {
                $('#organization_logo').after('<div class="logo-preview"><img src="' + image_url + '" alt="Logo Preview" style="max-width: 300px; margin-top: 10px;"></div>');
            }
        });
    });
});
</script>
