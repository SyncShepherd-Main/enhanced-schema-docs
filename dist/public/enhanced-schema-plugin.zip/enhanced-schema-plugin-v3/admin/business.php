<?php
/**
 * Local Business Settings Template
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['enhanced_schema_business_submit'])) {
    check_admin_referer('enhanced_schema_business_save');
    
    update_option('enhanced_schema_business_type', sanitize_text_field($_POST['business_type']));
    update_option('enhanced_schema_business_name', sanitize_text_field($_POST['business_name']));
    update_option('enhanced_schema_business_address', sanitize_text_field($_POST['business_address']));
    update_option('enhanced_schema_business_city', sanitize_text_field($_POST['business_city']));
    update_option('enhanced_schema_business_state', sanitize_text_field($_POST['business_state']));
    update_option('enhanced_schema_business_zip', sanitize_text_field($_POST['business_zip']));
    update_option('enhanced_schema_business_country', sanitize_text_field($_POST['business_country']));
    update_option('enhanced_schema_business_phone', sanitize_text_field($_POST['business_phone']));
    update_option('enhanced_schema_business_email', sanitize_email($_POST['business_email']));
    update_option('enhanced_schema_business_latitude', sanitize_text_field($_POST['business_latitude']));
    update_option('enhanced_schema_business_longitude', sanitize_text_field($_POST['business_longitude']));
    update_option('enhanced_schema_business_hours', sanitize_textarea_field($_POST['business_hours']));
    update_option('enhanced_schema_georadius_enabled', isset($_POST['georadius_enabled']) ? '1' : '0');
    update_option('enhanced_schema_georadius_postal_codes', sanitize_textarea_field($_POST['georadius_postal_codes']));
    
    echo '<div class="notice notice-success is-dismissible"><p>Local business settings saved successfully!</p></div>';
}

// Get current values
$business_type = get_option('enhanced_schema_business_type', 'LocalBusiness');
$business_name = get_option('enhanced_schema_business_name', get_bloginfo('name'));
$business_address = get_option('enhanced_schema_business_address', '');
$business_city = get_option('enhanced_schema_business_city', '');
$business_state = get_option('enhanced_schema_business_state', '');
$business_zip = get_option('enhanced_schema_business_zip', '');
$business_country = get_option('enhanced_schema_business_country', 'US');
$business_phone = get_option('enhanced_schema_business_phone', '');
$business_email = get_option('enhanced_schema_business_email', '');
$business_latitude = get_option('enhanced_schema_business_latitude', '');
$business_longitude = get_option('enhanced_schema_business_longitude', '');
$business_hours = get_option('enhanced_schema_business_hours', '');
$georadius_enabled = get_option('enhanced_schema_georadius_enabled', '0');
$georadius_postal_codes = get_option('enhanced_schema_georadius_postal_codes', '');
?>

<div class="wrap enhanced-schema-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <p class="description">Configure your local business information and service area.</p>
    
    <form method="post" action="">
        <?php wp_nonce_field('enhanced_schema_business_save'); ?>
        
        <h2>Business Type</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="business_type">Business Type *</label>
                </th>
                <td>
                    <select name="business_type" id="business_type" class="regular-text">
                        <option value="LocalBusiness" <?php selected($business_type, 'LocalBusiness'); ?>>Local Business</option>
                        <option value="Restaurant" <?php selected($business_type, 'Restaurant'); ?>>Restaurant</option>
                        <option value="Store" <?php selected($business_type, 'Store'); ?>>Store</option>
                        <option value="ProfessionalService" <?php selected($business_type, 'ProfessionalService'); ?>>Professional Service</option>
                        <option value="HomeAndConstructionBusiness" <?php selected($business_type, 'HomeAndConstructionBusiness'); ?>>Home & Construction</option>
                        <option value="AutoRepair" <?php selected($business_type, 'AutoRepair'); ?>>Auto Repair</option>
                        <option value="HealthAndBeautyBusiness" <?php selected($business_type, 'HealthAndBeautyBusiness'); ?>>Health & Beauty</option>
                        <option value="LegalService" <?php selected($business_type, 'LegalService'); ?>>Legal Service</option>
                        <option value="RealEstateAgent" <?php selected($business_type, 'RealEstateAgent'); ?>>Real Estate Agent</option>
                    </select>
                    <p class="description">Select the most specific business type that applies.</p>
                </td>
            </tr>
        </table>
        
        <h2>Business Information</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="business_name">Business Name *</label>
                </th>
                <td>
                    <input type="text" name="business_name" id="business_name" value="<?php echo esc_attr($business_name); ?>" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_address">Street Address *</label>
                </th>
                <td>
                    <input type="text" name="business_address" id="business_address" value="<?php echo esc_attr($business_address); ?>" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_city">City *</label>
                </th>
                <td>
                    <input type="text" name="business_city" id="business_city" value="<?php echo esc_attr($business_city); ?>" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_state">State/Province *</label>
                </th>
                <td>
                    <input type="text" name="business_state" id="business_state" value="<?php echo esc_attr($business_state); ?>" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_zip">ZIP/Postal Code *</label>
                </th>
                <td>
                    <input type="text" name="business_zip" id="business_zip" value="<?php echo esc_attr($business_zip); ?>" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_country">Country *</label>
                </th>
                <td>
                    <input type="text" name="business_country" id="business_country" value="<?php echo esc_attr($business_country); ?>" class="regular-text" required>
                    <p class="description">Two-letter country code (e.g., US, CA, GB).</p>
                </td>
            </tr>
        </table>
        
        <h2>Contact Information</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="business_phone">Phone Number *</label>
                </th>
                <td>
                    <input type="tel" name="business_phone" id="business_phone" value="<?php echo esc_attr($business_phone); ?>" class="regular-text" required>
                    <p class="description">Format: +1-555-555-5555</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_email">Email Address</label>
                </th>
                <td>
                    <input type="email" name="business_email" id="business_email" value="<?php echo esc_attr($business_email); ?>" class="regular-text">
                </td>
            </tr>
        </table>
        
        <h2>Geographic Coordinates</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="business_latitude">Latitude</label>
                </th>
                <td>
                    <input type="text" name="business_latitude" id="business_latitude" value="<?php echo esc_attr($business_latitude); ?>" class="regular-text">
                    <p class="description">Decimal format (e.g., 34.0522)</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="business_longitude">Longitude</label>
                </th>
                <td>
                    <input type="text" name="business_longitude" id="business_longitude" value="<?php echo esc_attr($business_longitude); ?>" class="regular-text">
                    <p class="description">Decimal format (e.g., -118.2437)</p>
                </td>
            </tr>
        </table>
        
        <h2>Business Hours</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="business_hours">Operating Hours</label>
                </th>
                <td>
                    <textarea name="business_hours" id="business_hours" rows="7" class="large-text" placeholder="Monday: 9:00 AM - 5:00 PM&#10;Tuesday: 9:00 AM - 5:00 PM&#10;Wednesday: 9:00 AM - 5:00 PM&#10;Thursday: 9:00 AM - 5:00 PM&#10;Friday: 9:00 AM - 5:00 PM&#10;Saturday: Closed&#10;Sunday: Closed"><?php echo esc_textarea($business_hours); ?></textarea>
                    <p class="description">Enter your business hours, one day per line.</p>
                </td>
            </tr>
        </table>
        
        <h2>Service Area (Georadius)</h2>
        
        <table class="form-table">
            <tr>
                <th scope="row">Enable Georadius</th>
                <td>
                    <label>
                        <input type="checkbox" name="georadius_enabled" value="1" <?php checked($georadius_enabled, '1'); ?>>
                        Enable service area with postal codes
                    </label>
                    <p class="description">Define your service area using postal codes for areaServed schema.</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="georadius_postal_codes">Postal Codes</label>
                </th>
                <td>
                    <textarea name="georadius_postal_codes" id="georadius_postal_codes" rows="10" class="large-text" placeholder="90001&#10;90002&#10;90003&#10;..."><?php echo esc_textarea($georadius_postal_codes); ?></textarea>
                    <p class="description">Enter postal codes you serve, one per line. The plugin will automatically map these to cities and states.</p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="enhanced_schema_business_submit" class="button button-primary" value="Save Local Business Settings">
        </p>
    </form>
</div>
