<?php
/**
 * Frontend Schema Output Class
 * Outputs schema markup to the website frontend
 */

class Enhanced_Schema_Frontend {
    
    public function __construct() {
        add_action('wp_head', array($this, 'output_schema'), 99);
        add_action('wp_ajax_enhanced_schema_generate', array($this, 'ajax_generate_schema'));
    }
    
    /**
     * Output schema to wp_head
     */
    public function output_schema() {
        $schemas = Enhanced_Schema_Generator::generate_schema();
        
        if (empty($schemas)) {
            return;
        }
        
        // Filter out null schemas
        $schemas = array_filter($schemas);
        
        if (empty($schemas)) {
            return;
        }
        
        // Output as JSON-LD
        echo "\n<!-- Enhanced Schema Plugin -->\n";
        echo '<script type="application/ld+json">' . "\n";
        
        if (count($schemas) === 1) {
            echo wp_json_encode($schemas[0], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        } else {
            echo wp_json_encode(array('@graph' => $schemas), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        }
        
        echo "\n</script>\n";
        echo "<!-- /Enhanced Schema Plugin -->\n\n";
    }
    
    /**
     * AJAX handler for schema generation
     */
    public function ajax_generate_schema() {
        check_ajax_referer('enhanced_schema_generate', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        
        if (!$url) {
            wp_send_json_error('Invalid URL');
            return;
        }
        
        // Get post ID from URL
        $post_id = url_to_postid($url);
        
        if (!$post_id) {
            // Try homepage
            if ($url === home_url('/') || $url === home_url()) {
                $post_id = get_option('page_on_front');
            }
        }
        
        if (!$post_id) {
            wp_send_json_error('Could not find post for URL');
            return;
        }
        
        // Generate schema
        $schemas = Enhanced_Schema_Generator::generate_schema($post_id);
        
        if (empty($schemas)) {
            wp_send_json_error('No schema generated');
            return;
        }
        
        // Filter out null schemas
        $schemas = array_filter($schemas);
        
        if (count($schemas) === 1) {
            wp_send_json_success($schemas[0]);
        } else {
            wp_send_json_success(array('@graph' => $schemas));
        }
    }
}
