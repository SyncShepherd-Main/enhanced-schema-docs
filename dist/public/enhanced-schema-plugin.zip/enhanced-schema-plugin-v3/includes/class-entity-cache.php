<?php
/**
 * Entity Cache Class
 * Manages caching of entities from Wikipedia/Wikidata
 */

class Enhanced_Schema_Entity_Cache {
    
    /**
     * Get cached entity or fetch from API
     */
    public static function get_entity($entity_name, $entity_type = 'general') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'enhanced_schema_entities';
        
        // Check if caching is enabled
        $cache_enabled = get_option('enhanced_schema_entity_cache_enabled', '1');
        if (!$cache_enabled) {
            return self::fetch_entity($entity_name, $entity_type);
        }
        
        // Check cache
        $cache_duration = get_option('enhanced_schema_entity_cache_duration', '7');
        $cache_expiry = date('Y-m-d H:i:s', strtotime("-{$cache_duration} days"));
        
        $cached = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE entity_name = %s AND cached_at > %s",
            $entity_name,
            $cache_expiry
        ));
        
        if ($cached) {
            return json_decode($cached->entity_data, true);
        }
        
        // Fetch fresh data
        $entity_data = self::fetch_entity($entity_name, $entity_type);
        
        if ($entity_data) {
            // Cache it
            $wpdb->replace(
                $table_name,
                array(
                    'entity_name' => $entity_name,
                    'entity_type' => $entity_type,
                    'entity_data' => wp_json_encode($entity_data),
                    'cached_at' => current_time('mysql')
                ),
                array('%s', '%s', '%s', '%s')
            );
        }
        
        return $entity_data;
    }
    
    /**
     * Fetch entity from Wikipedia/Wikidata
     */
    private static function fetch_entity($entity_name, $entity_type) {
        // Try Wikipedia first
        $wikipedia_data = self::fetch_from_wikipedia($entity_name);
        
        if ($wikipedia_data) {
            return $wikipedia_data;
        }
        
        // Fallback to basic data
        return array(
            'name' => $entity_name,
            'type' => $entity_type,
            'description' => '',
            'url' => ''
        );
    }
    
    /**
     * Fetch from Wikipedia API
     */
    private static function fetch_from_wikipedia($entity_name) {
        $url = 'https://en.wikipedia.org/w/api.php?' . http_build_query(array(
            'action' => 'query',
            'format' => 'json',
            'titles' => $entity_name,
            'prop' => 'extracts|pageimages',
            'exintro' => true,
            'explaintext' => true,
            'piprop' => 'original'
        ));
        
        $response = wp_remote_get($url, array('timeout' => 10));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['query']['pages'])) {
            return null;
        }
        
        $page = reset($data['query']['pages']);
        
        if (isset($page['missing'])) {
            return null;
        }
        
        $entity_data = array(
            'name' => $page['title'] ?? $entity_name,
            'type' => 'Thing',
            'description' => $page['extract'] ?? '',
            'url' => 'https://en.wikipedia.org/wiki/' . urlencode(str_replace(' ', '_', $page['title'] ?? $entity_name))
        );
        
        if (isset($page['original']['source'])) {
            $entity_data['image'] = $page['original']['source'];
        }
        
        return $entity_data;
    }
    
    /**
     * Clear entity cache
     */
    public static function clear_cache() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'enhanced_schema_entities';
        $wpdb->query("TRUNCATE TABLE $table_name");
    }
    
    /**
     * Get cache statistics
     */
    public static function get_cache_stats() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'enhanced_schema_entities';
        
        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        
        $cache_duration = get_option('enhanced_schema_entity_cache_duration', '7');
        $cache_expiry = date('Y-m-d H:i:s', strtotime("-{$cache_duration} days"));
        
        $valid = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE cached_at > %s",
            $cache_expiry
        ));
        
        return array(
            'total' => $total,
            'valid' => $valid,
            'expired' => $total - $valid
        );
    }
}
