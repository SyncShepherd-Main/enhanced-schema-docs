<?php
/**
 * Enhanced Schema Settings Class
 * Uses WordPress Settings API for reliable form rendering
 */

class Enhanced_Schema_Settings {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }
    
    /**
     * Add admin menu pages
     */
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            'Enhanced Schema',
            'Enhanced Schema',
            'manage_options',
            'enhanced-schema',
            array($this, 'dashboard_page'),
            'dashicons-networking',
            30
        );
        
        // Dashboard submenu
        add_submenu_page(
            'enhanced-schema',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'enhanced-schema',
            array($this, 'dashboard_page')
        );
        
        // General Settings
        add_submenu_page(
            'enhanced-schema',
            'General Settings',
            'General Settings',
            'manage_options',
            'enhanced-schema-settings',
            array($this, 'settings_page')
        );
        
        // Organization
        add_submenu_page(
            'enhanced-schema',
            'Organization',
            'Organization',
            'manage_options',
            'enhanced-schema-organization',
            array($this, 'organization_page')
        );
        
        // Local Business
        add_submenu_page(
            'enhanced-schema',
            'Local Business',
            'Local Business',
            'manage_options',
            'enhanced-schema-business',
            array($this, 'business_page')
        );
        
        // Schema Generator
        add_submenu_page(
            'enhanced-schema',
            'Schema Generator',
            'Schema Generator',
            'manage_options',
            'enhanced-schema-generator',
            array($this, 'generator_page')
        );
    }
    
    /**
     * Register all settings
     */
    public function register_settings() {
        // General Settings
        register_setting('enhanced_schema_general', 'enhanced_schema_schema_enabled');
        register_setting('enhanced_schema_general', 'enhanced_schema_schema_types');
        register_setting('enhanced_schema_general', 'enhanced_schema_entity_cache_enabled');
        register_setting('enhanced_schema_general', 'enhanced_schema_entity_cache_duration');
        
        // Organization Settings
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_name');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_url');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_logo');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_description');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_phone');
        register_setting('enhanced_schema_organization', 'enhanced_schema_organization_email');
        
        // Local Business Settings
        register_setting('enhanced_schema_business', 'enhanced_schema_business_type');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_name');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_address');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_city');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_state');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_zip');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_country');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_phone');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_email');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_latitude');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_longitude');
        register_setting('enhanced_schema_business', 'enhanced_schema_business_hours');
        register_setting('enhanced_schema_business', 'enhanced_schema_georadius_enabled');
        register_setting('enhanced_schema_business', 'enhanced_schema_georadius_postal_codes');
        
        // API Settings
        register_setting('enhanced_schema_general', 'enhanced_schema_google_places_api_key');
        register_setting('enhanced_schema_general', 'enhanced_schema_openai_api_key');
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'enhanced-schema') === false) {
            return;
        }
        
        wp_enqueue_style(
            'enhanced-schema-admin',
            ENHANCED_SCHEMA_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ENHANCED_SCHEMA_VERSION
        );
        
        wp_enqueue_script(
            'enhanced-schema-admin',
            ENHANCED_SCHEMA_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            ENHANCED_SCHEMA_VERSION,
            true
        );
    }
    
    /**
     * Dashboard Page
     */
    public function dashboard_page() {
        $schema_enabled = get_option('enhanced_schema_schema_enabled', '1');
        $schema_types = get_option('enhanced_schema_schema_types', array());
        $enabled_count = count(array_filter($schema_types));
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'enhanced_schema_entities';
        $entity_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/dashboard.php';
    }
    
    /**
     * General Settings Page
     */
    public function settings_page() {
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/settings.php';
    }
    
    /**
     * Organization Page
     */
    public function organization_page() {
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/organization.php';
    }
    
    /**
     * Local Business Page
     */
    public function business_page() {
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/business.php';
    }
    
    /**
     * Schema Generator Page
     */
    public function generator_page() {
        include ENHANCED_SCHEMA_PLUGIN_DIR . 'admin/generator.php';
    }
}
