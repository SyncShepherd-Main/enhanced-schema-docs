<?php
/**
 * Schema Generator Class
 * Generates schema markup based on page content and settings
 */

class Enhanced_Schema_Generator {
    
    /**
     * Generate schema for a given post/page
     */
    public static function generate_schema($post_id = null) {
        if (!$post_id) {
            $post_id = get_the_ID();
        }
        
        if (!$post_id) {
            return array();
        }
        
        $schema_enabled = get_option('enhanced_schema_schema_enabled', '1');
        if (!$schema_enabled) {
            return array();
        }
        
        $schema_types = get_option('enhanced_schema_schema_types', array());
        $schemas = array();
        
        // Webpage Schema
        if (isset($schema_types['webpage']) && $schema_types['webpage']) {
            $schemas[] = self::generate_webpage_schema($post_id);
        }
        
        // Organization Schema
        if (isset($schema_types['organization']) && $schema_types['organization']) {
            $schemas[] = self::generate_organization_schema();
        }
        
        // Local Business Schema
        if (isset($schema_types['local_business']) && $schema_types['local_business']) {
            $schemas[] = self::generate_local_business_schema();
        }
        
        // Breadcrumb Schema
        if (isset($schema_types['breadcrumb']) && $schema_types['breadcrumb']) {
            $breadcrumb = self::generate_breadcrumb_schema($post_id);
            if ($breadcrumb) {
                $schemas[] = $breadcrumb;
            }
        }
        
        // Article Schema (for posts)
        if (isset($schema_types['article']) && $schema_types['article'] && get_post_type($post_id) === 'post') {
            $schemas[] = self::generate_article_schema($post_id);
        }
        
        return $schemas;
    }
    
    /**
     * Generate Webpage Schema
     */
    private static function generate_webpage_schema($post_id) {
        $post = get_post($post_id);
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            '@id' => get_permalink($post_id) . '#webpage',
            'url' => get_permalink($post_id),
            'name' => get_the_title($post_id),
            'description' => get_the_excerpt($post_id),
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'inLanguage' => get_bloginfo('language'),
            'isPartOf' => array(
                '@type' => 'WebSite',
                '@id' => home_url('/') . '#website',
                'url' => home_url('/'),
                'name' => get_bloginfo('name')
            )
        );
    }
    
    /**
     * Generate Organization Schema
     */
    private static function generate_organization_schema() {
        $org_name = get_option('enhanced_schema_organization_name', get_bloginfo('name'));
        $org_url = get_option('enhanced_schema_organization_url', get_site_url());
        $org_logo = get_option('enhanced_schema_organization_logo', '');
        $org_description = get_option('enhanced_schema_organization_description', '');
        $org_phone = get_option('enhanced_schema_organization_phone', '');
        $org_email = get_option('enhanced_schema_organization_email', '');
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            '@id' => $org_url . '#organization',
            'name' => $org_name,
            'url' => $org_url
        );
        
        if ($org_logo) {
            $schema['logo'] = array(
                '@type' => 'ImageObject',
                'url' => $org_logo
            );
        }
        
        if ($org_description) {
            $schema['description'] = $org_description;
        }
        
        if ($org_phone || $org_email) {
            $schema['contactPoint'] = array(
                '@type' => 'ContactPoint',
                'contactType' => 'customer service'
            );
            
            if ($org_phone) {
                $schema['contactPoint']['telephone'] = $org_phone;
            }
            
            if ($org_email) {
                $schema['contactPoint']['email'] = $org_email;
            }
        }
        
        return $schema;
    }
    
    /**
     * Generate Local Business Schema
     */
    private static function generate_local_business_schema() {
        $business_type = get_option('enhanced_schema_business_type', 'LocalBusiness');
        $business_name = get_option('enhanced_schema_business_name', '');
        $business_address = get_option('enhanced_schema_business_address', '');
        $business_city = get_option('enhanced_schema_business_city', '');
        $business_state = get_option('enhanced_schema_business_state', '');
        $business_zip = get_option('enhanced_schema_business_zip', '');
        $business_country = get_option('enhanced_schema_business_country', 'US');
        $business_phone = get_option('enhanced_schema_business_phone', '');
        $business_email = get_option('enhanced_schema_business_email', '');
        $business_latitude = get_option('enhanced_schema_business_latitude', '');
        $business_longitude = get_option('enhanced_schema_business_longitude', '');
        $georadius_enabled = get_option('enhanced_schema_georadius_enabled', '0');
        $georadius_postal_codes = get_option('enhanced_schema_georadius_postal_codes', '');
        
        if (!$business_name || !$business_address) {
            return null;
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => $business_type,
            '@id' => get_site_url() . '#localbusiness',
            'name' => $business_name,
            'url' => get_site_url(),
            'address' => array(
                '@type' => 'PostalAddress',
                'streetAddress' => $business_address,
                'addressLocality' => $business_city,
                'addressRegion' => $business_state,
                'postalCode' => $business_zip,
                'addressCountry' => $business_country
            )
        );
        
        if ($business_phone) {
            $schema['telephone'] = $business_phone;
        }
        
        if ($business_email) {
            $schema['email'] = $business_email;
        }
        
        if ($business_latitude && $business_longitude) {
            $schema['geo'] = array(
                '@type' => 'GeoCoordinates',
                'latitude' => $business_latitude,
                'longitude' => $business_longitude
            );
        }
        
        // Add service area if georadius is enabled
        if ($georadius_enabled && $georadius_postal_codes) {
            $postal_codes = array_filter(array_map('trim', explode("\n", $georadius_postal_codes)));
            
            if (!empty($postal_codes)) {
                $areas_served = array();
                
                foreach ($postal_codes as $postal_code) {
                    $areas_served[] = array(
                        '@type' => 'PostalCodeRange',
                        'postalCode' => $postal_code
                    );
                }
                
                $schema['areaServed'] = $areas_served;
            }
        }
        
        return $schema;
    }
    
    /**
     * Generate Breadcrumb Schema
     */
    private static function generate_breadcrumb_schema($post_id) {
        if (is_front_page()) {
            return null;
        }
        
        $items = array();
        $position = 1;
        
        // Home
        $items[] = array(
            '@type' => 'ListItem',
            'position' => $position++,
            'name' => 'Home',
            'item' => home_url('/')
        );
        
        // Category/Parent pages
        if (is_single()) {
            $categories = get_the_category($post_id);
            if (!empty($categories)) {
                $category = $categories[0];
                $items[] = array(
                    '@type' => 'ListItem',
                    'position' => $position++,
                    'name' => $category->name,
                    'item' => get_category_link($category->term_id)
                );
            }
        }
        
        // Current page
        $items[] = array(
            '@type' => 'ListItem',
            'position' => $position,
            'name' => get_the_title($post_id),
            'item' => get_permalink($post_id)
        );
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items
        );
    }
    
    /**
     * Generate Article Schema
     */
    private static function generate_article_schema($post_id) {
        $post = get_post($post_id);
        $author = get_the_author_meta('display_name', $post->post_author);
        $thumbnail = get_the_post_thumbnail_url($post_id, 'full');
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            '@id' => get_permalink($post_id) . '#article',
            'headline' => get_the_title($post_id),
            'description' => get_the_excerpt($post_id),
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'author' => array(
                '@type' => 'Person',
                'name' => $author
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => get_bloginfo('name'),
                'url' => get_site_url()
            )
        );
        
        if ($thumbnail) {
            $schema['image'] = $thumbnail;
        }
        
        return $schema;
    }
}
