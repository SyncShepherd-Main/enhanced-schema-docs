# Enhanced Schema Plugin v3.0

Comprehensive WordPress schema markup plugin with automated webpage schema, local business georadius, entity detection, and advanced SEO features designed for agencies.

## Features

### Core Schema Types
- **Webpage Schema** - Automatic schema for all pages and posts
- **Organization Schema** - Company information and branding
- **Local Business Schema** - Local business with georadius support
- **Article Schema** - Blog posts and articles
- **Product Schema** - E-commerce products
- **Event Schema** - Events and happenings
- **Recipe Schema** - Cooking recipes
- **Video Schema** - Automatic detection of embedded videos
- **FAQ Schema** - Automatic FAQ detection from content
- **Review Schema** - Product and service reviews
- **How-To Schema** - Step-by-step guides
- **Breadcrumb Schema** - Navigation breadcrumbs

### Advanced Features
- **Automated Schema Generation** - Automatically generates appropriate schema for each page
- **Georadius Support** - Define service areas using postal codes with areaServed schema
- **Entity Detection & Caching** - Detects and caches entities from Wikipedia/Wikidata
- **Schema Validation** - Built-in schema generator and preview tool
- **API Integration** - Google Places API and OpenAI API support
- **Multi-site Ready** - Use across unlimited agency websites

## Installation

1. Download the plugin ZIP file
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin" and select the ZIP file
4. Click "Install Now" and then "Activate"

## Configuration

### General Settings
1. Go to **Enhanced Schema → General Settings**
2. Enable schema generation
3. Select which schema types to enable
4. Configure entity caching options
5. Add API keys (optional)

### Organization Information
1. Go to **Enhanced Schema → Organization**
2. Fill in your organization details:
   - Organization name
   - Website URL
   - Logo
   - Description
   - Contact information

### Local Business Setup
1. Go to **Enhanced Schema → Local Business**
2. Configure your business information:
   - Business type
   - Address
   - Phone and email
   - Geographic coordinates
   - Business hours
3. Enable georadius and add postal codes for service area

### Testing Schema
1. Go to **Enhanced Schema → Schema Generator**
2. Enter a page URL from your site
3. Click "Generate Schema" to preview
4. Use Google Rich Results Test to validate

## Usage

Once configured, the plugin automatically generates and outputs schema markup for all pages on your site. No additional action required!

### Viewing Schema Output
- View page source and look for `<script type="application/ld+json">` tags
- Use the Schema Generator tool in the admin
- Test with Google's Rich Results Test tool

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- MySQL 5.6 or higher

## Support

For support, feature requests, or bug reports, please contact your agency administrator.

## Changelog

### Version 3.0.0
- Complete rebuild using WordPress Settings API
- Improved form rendering and reliability
- Enhanced admin interface
- Better schema generation
- Improved entity caching
- Added schema preview tool

### Version 2.0.0
- Added georadius support
- Entity detection and caching
- Multiple schema types
- API integrations

### Version 1.0.0
- Initial release
- Basic schema generation

## License

GPL v2 or later

## Credits

Developed for agency use with features inspired by SchemaWriter.ai
