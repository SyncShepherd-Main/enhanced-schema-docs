<?php
/**
 * Plugin Name: Enhanced Schema Plugin
 * Plugin URI: https://your-agency.com/enhanced-schema
 * Description: Comprehensive schema markup plugin with automated webpage schema, local business georadius, entity detection, and advanced SEO features for agencies.
 * Version: 3.0.0
 * Author: Your Agency
 * Author URI: https://your-agency.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: enhanced-schema
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ENHANCED_SCHEMA_VERSION', '3.0.0');
define('ENHANCED_SCHEMA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ENHANCED_SCHEMA_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-settings.php';
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-schema-generator.php';
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-frontend.php';
require_once ENHANCED_SCHEMA_PLUGIN_DIR . 'includes/class-entity-cache.php';

// Initialize the plugin
function enhanced_schema_init() {
    // Initialize settings
    new Enhanced_Schema_Settings();
    
    // Initialize frontend output
    new Enhanced_Schema_Frontend();
}
add_action('plugins_loaded', 'enhanced_schema_init');

// Activation hook
register_activation_hook(__FILE__, 'enhanced_schema_activate');
function enhanced_schema_activate() {
    // Set default options
    $defaults = array(
        'schema_enabled' => '1',
        'schema_types' => array(
            'webpage' => '1',
            'organization' => '1',
            'local_business' => '0',
            'video' => '1',
            'faq' => '1',
            'article' => '0',
            'product' => '0',
            'event' => '0',
            'recipe' => '0',
            'review' => '0',
            'howto' => '0',
            'breadcrumb' => '1'
        ),
        'organization_name' => get_bloginfo('name'),
        'organization_url' => get_site_url(),
        'organization_logo' => '',
        'organization_description' => get_bloginfo('description'),
        'business_type' => 'LocalBusiness',
        'business_name' => get_bloginfo('name'),
        'business_address' => '',
        'business_city' => '',
        'business_state' => '',
        'business_zip' => '',
        'business_country' => 'US',
        'business_phone' => '',
        'business_email' => '',
        'business_latitude' => '',
        'business_longitude' => '',
        'business_hours' => '',
        'georadius_enabled' => '0',
        'georadius_postal_codes' => '',
        'entity_cache_enabled' => '1',
        'entity_cache_duration' => '7',
        'google_places_api_key' => '',
        'openai_api_key' => ''
    );
    
    foreach ($defaults as $key => $value) {
        if (get_option('enhanced_schema_' . $key) === false) {
            add_option('enhanced_schema_' . $key, $value);
        }
    }
    
    // Create entity cache table
    global $wpdb;
    $table_name = $wpdb->prefix . 'enhanced_schema_entities';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        entity_name varchar(255) NOT NULL,
        entity_type varchar(50) NOT NULL,
        entity_data longtext NOT NULL,
        cached_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        KEY entity_name (entity_name)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'enhanced_schema_deactivate');
function enhanced_schema_deactivate() {
    // Clean up if needed
}
